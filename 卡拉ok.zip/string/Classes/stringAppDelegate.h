//
//  stringAppDelegate.h
//  string
//
//  Created by sk on 11-8-29.
//  Copyright 2011 sk. All rights reserved.
//

#import <UIKit/UIKit.h>

@class stringViewController;

@interface stringAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    stringViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet stringViewController *viewController;

@end

