//
//  stringViewController.m
//  string
//
//  Created by sk on 11-8-29.
//  Copyright 2011 sk. All rights reserved.
//

#import "stringViewController.h"
#import"mystring.h"
#define TEXT @"❤爱的宣言❤当岁末的眼泪化为深冬的冰凌当远方的问候迷失在粗心的情怀我依然固执地用凝霜的枯枝在凄凉的大地上写下：我爱你当眼中的希望指向天边的云朵当爱情的能量托起沉睡的太阳我依然固执的颤动着那枝倾心的笔杆用纯情的笔体写下：大爱无言当严冬无情地查封着冰冷的世界 当落花的余香叹息着短暂的花季 我依然固执地铺平天边的落叶 用凄丽的晶雪在世界的边缘写下：❤爱的宣言❤..."
@implementation stringViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	mystring *my = [[mystring alloc]initWithFrame:CGRectMake(0.0, 0.0, 320, 460)];
	my.backgroundColor = [UIColor blueColor];
	[self.view addSubview:my];
	[my settext:TEXT];
	[my release];
	
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
