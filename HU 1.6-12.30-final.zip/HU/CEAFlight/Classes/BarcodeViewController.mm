//
//  BarcodeViewController.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BarcodeViewController.h"
#import "AirlineViewController.h"
#import "Barcode/QRCodeReader.h"

@implementation BarcodeViewController

@synthesize resultImage;
@synthesize messageText;
@synthesize cameraBtn;
@synthesize libraryBtn;

@synthesize imageView;
@synthesize lblLoading;
@synthesize resultPointViews;
@synthesize noImage;


- (void)gotoDetailView
{
	app.window.userInteractionEnabled = YES;
	self.tabBarController.selectedIndex = 1;
}

- (IBAction)pickAndDecode:(id)sender
{
	int i = [sender tag];
	if (i == 0)
	{
		[self showCaptureView];
	}
	else if(i == 1)
	{
		isPhotoLibraryUp = TRUE;
		imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		[self presentModalViewController:imagePickerController animated:YES];
	}
}

- (void)showCaptureView
{
	ZXingWidgetController *widController = [[ZXingWidgetController alloc] initWithDelegate:self showCancel:YES OneDMode:NO];
	QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
	NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
	[qrcodeReader release];
	widController.readers = readers;
	[readers release];
	[self presentModalViewController:widController animated:YES];
	[widController release];
}

- (void)clearImageView
{
	imageView.image = noImage;
	
	for (UIView *view in resultPointViews) {
		[view removeFromSuperview];
	}
	[resultPointViews removeAllObjects];
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)pickAndDecodeFromSource:(UIImagePickerControllerSourceType)sourceType
{
	
}

- (void)imagePickerController:(UIImagePickerController *)picker
        didFinishPickingImage:(UIImage *)image
                  editingInfo:(NSDictionary *)editingInfo
{
	UIImage *imageToDecode = image;
	CGSize size = [image size];
	
	CGRect cropRect = CGRectMake(0.0, 0.0, size.width, size.height); 
	
    // give the taken picture to our delegate
    
	self.messageText.text = @"";
	[decoder decodeImage:imageToDecode cropRect:cropRect];
	
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[self dismissModalViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark ZXingDelegateMethods
- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)resultStr {
	
	AudioServicesPlaySystemSound (soundFileObject);
	NSLog(@"AudioServicesPlaySystemSound (soundFileObject);");
	
	if (self.isViewLoaded) 
	{
		messageText.text = resultStr;
		[messageText setNeedsDisplay];
	}
	[self dismissModalViewControllerAnimated:NO];
	
	app.isAlreadyGetBarcode = YES;
	app.randomNum = rand()%6;
	
	lblLoading.hidden = NO;
	app.window.userInteractionEnabled = NO;
	[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(gotoDetailView) userInfo:nil repeats:NO];

}

- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller {
	[self dismissModalViewControllerAnimated:YES];
}

- (void)presentResultForString:(NSString *)resultString 
{
	self.messageText.text = resultString;
} 

- (void)presentResultPoints:(NSArray *)resultPoints 
                   forImage:(UIImage *)image
                usingSubset:(UIImage *)subset
{
	// simply add the points to the image view
	imageView.image = subset;
	for (NSValue *pointValue in resultPoints) {
		[imageView addResultPoint:[pointValue CGPointValue]];
	}
}

#pragma mark -
#pragma mark DecoderDelegate methods
- (void)decoder:(Decoder *)decoder willDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset
{
	NSLog(@"====decoder:willDecodeImage");
	[self clearImageView];
	[self.imageView setImage:subset];
}

- (void)decoder:(Decoder *)decoder decodingImage:(UIImage *)image usingSubset:(UIImage *)subset progress:(NSString *) message
{
	NSLog(@"====decoder:decodingImage");
	[self clearImageView];
	[self.imageView setImage:subset];
}

- (void)decoder:(Decoder *)decoder didDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset withResult:(TwoDDecoderResult *)twoDResult
{
	NSLog(@"====decoder:didDecodeImage");
	isFirstDecode = YES;
	app.isAlreadyGetBarcode = YES;
	app.randomNum = rand()%6;
	
	lblLoading.hidden = NO;
	
	
	AudioServicesPlaySystemSound (soundFileObject);
	NSLog(@"AudioServicesPlaySystemSound (soundFileObject);");
	
	[self presentResultForString:twoDResult.text];
	
	[self presentResultPoints:twoDResult.points forImage:image usingSubset:subset];
	
	[self dismissModalViewControllerAnimated:YES];
	app.window.userInteractionEnabled = NO;
	[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(gotoDetailView) userInfo:nil repeats:NO];
}

- (void)decoder:(Decoder *)decoder failedToDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset reason:(NSString *)reason
{
	//to do
	NSLog(@"---decoder:failedToDecodeImage:---");
	[self dismissModalViewControllerAnimated:YES];
	[self presentResultForString:@"Decode failed! Please retake the picture to decode!"];
}


#pragma mark -
#pragma mark ViewDefaultMethods
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	decoder = [[Decoder alloc] init];
	decoder.delegate = self;
	QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
	NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
	[qrcodeReader release];
	decoder.readers = readers;
	[readers release];
	
    resultPointViews = [[NSMutableArray alloc] init];
	
	self.navigationController.navigationBar.hidden = YES;
	app = (CEAFlightAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	messageText.backgroundColor = [UIColor clearColor];
	messageText.text = @"Please get a barcode picture!";
	
	imageView.backgroundColor = [UIColor clearColor];
	
	self.noImage = [UIImage imageNamed:@"sorry.png"];
	imageView.image = noImage;

	imagePickerController = [[UIImagePickerController alloc] init];
	imagePickerController.delegate = self;
	
	 if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
	 {
		 cameraBtn.enabled = false;
	 }
	
	isFirstDecode = FALSE;
	isPhotoLibraryUp = FALSE;
	
	//识别成功提示声
	CFBundleRef mainBundle;
	mainBundle = CFBundleGetMainBundle ();
	soundFileURLRef  =	CFBundleCopyResourceURL (
												 mainBundle,
												 CFSTR ("beep"),
												 CFSTR ("aif"),
												 NULL
												 );
	AudioServicesCreateSystemSoundID (
									  soundFileURLRef,
									  &soundFileObject
									  );
}

- (void)viewWillAppear:(BOOL)animated
{
	lblLoading.hidden = YES;
	
	if (!isPhotoLibraryUp)
	{
		//[self showCaptureView];
	}
	isPhotoLibraryUp = FALSE;
}

- (void)viewDidAppear:(BOOL)animated
{
	if (isFirstDecode)
	{
		lblLoading.hidden = NO;
		isFirstDecode = FALSE;
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
//	self.noImage = nil;
}


- (void)dealloc {
    [super dealloc];
	[imagePickerController release];
	[resultPointViews release];
//	[noImage release];
	
	
	AudioServicesDisposeSystemSoundID (soundFileObject);
	CFRelease (soundFileURLRef);
}


@end
