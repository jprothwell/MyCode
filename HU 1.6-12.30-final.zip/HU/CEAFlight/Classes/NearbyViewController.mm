//
//  NearbyViewController.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "NearbyViewController.h"


@implementation NearbyViewController

@synthesize btnReturn;
@synthesize btnLeft;
@synthesize btnRight;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */

- (IBAction) OnBtnReturn:(id) sender
{
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem = nil;
	self.navigationItem.leftBarButtonItem = self.btnLeft;
	self.navigationItem.rightBarButtonItem = self.btnRight;
	[self.viewAirport.viewDetailInfo HideInfo];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	[self InitMapInfo:@"map2"
	   InitDblClkMode:DBLCLK_MODE_DETAIL];
	self.btnLeft = self.navigationItem.leftBarButtonItem;
	self.btnRight = self.navigationItem.rightBarButtonItem;
	UIBarButtonItem* tmpBtnItem = [[UIBarButtonItem alloc] initWithTitle:@"返回"
																   style:UIBarButtonItemStyleBordered
																  target:self
																  action:@selector(OnBtnReturn:)];
	self.btnReturn = tmpBtnItem;
	[tmpBtnItem release];
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload 
{
	[btnReturn release];
	[btnLeft release];
	[btnRight release];
	[super viewDidUnload];
}


- (void)dealloc {
    [super dealloc];
}

- (IBAction) OnDblClkModeChanged:(id) sender
{
	int nIndex = [segmentCtl selectedSegmentIndex];
	[self.viewAirport SetDblClkMode:nIndex];
}

- (void) AfterDoubleClick:(int) nMode
{
	if (DBLCLK_MODE_SET_BEGIN_POINT == nMode)
	{
		[segmentCtl setSelectedSegmentIndex:2];
	}
	else if (DBLCLK_MODE_DETAIL == nMode)
	{
		self.navigationItem.leftBarButtonItem = nil;
		self.navigationItem.rightBarButtonItem = nil;
		self.navigationItem.leftBarButtonItem = self.btnReturn;
	}
	else
	{
		//do nothing
	}
}

@end
