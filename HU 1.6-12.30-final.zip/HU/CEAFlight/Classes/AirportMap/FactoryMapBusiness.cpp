#include "factorymapbusiness.h"

CMapBusiness* CreateBusiness2D()
{
    return new CMapBusiness2D;
}

CFactoryMapBusiness::CFactoryMapBusiness(void)
{
    Register(MAP_BUSINESS_2D, CreateBusiness2D);
}

CFactoryMapBusiness::~CFactoryMapBusiness(void)
{
}
