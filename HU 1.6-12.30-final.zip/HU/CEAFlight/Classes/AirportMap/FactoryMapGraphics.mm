#include "factorymapgraphics.h"

CMapGraphics* CreateGraphics2D()
{
    return new CMapGraphics2D;
}

CFactoryMapGraphics::CFactoryMapGraphics(void)
{
    Register(MAP_GRAPHICS_2D, CreateGraphics2D);
}

CFactoryMapGraphics::~CFactoryMapGraphics(void)
{
}
