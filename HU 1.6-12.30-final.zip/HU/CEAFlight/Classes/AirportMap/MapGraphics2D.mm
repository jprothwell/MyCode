#include "MapBusiness2D.h"
#include "MapGraphics2D.h"

@implementation UIImage (scale)

- (UIImage*) scaleToSize:(CGSize)sizeMap
{
	UIGraphicsBeginImageContext(sizeMap);
	
	[self drawInRect:CGRectMake(0, 0, sizeMap.width, sizeMap.height)];
	UIImage* imageScale = UIGraphicsGetImageFromCurrentImageContext();
	
	UIGraphicsEndImageContext();
	return imageScale;
}

- (UIImage*) scaleAndRotateImage:(CGFloat)bounds_width:(CGFloat)bounds_height
{
    //int kMaxResolution = 300;
	
    CGImageRef imgRef = self.CGImage;
	
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
	
	
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    /*if (width > kMaxResolution || height > kMaxResolution)
	 {
	 CGFloat ratio = width/height;
	 if (ratio > 1)
	 {
	 bounds.size.width = kMaxResolution;
	 bounds.size.height = bounds.size.width / ratio;
	 }
	 else
	 {
	 bounds.size.height = kMaxResolution;
	 bounds.size.width = bounds.size.height * ratio;
	 }
	 }*/
    bounds.size.width = bounds_width;
    bounds.size.height = bounds_height;
	
    CGFloat scaleRatio = bounds.size.width / width;
    CGFloat scaleRatioheight = bounds.size.height / height;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = self.imageOrientation;
    switch(orient)
    {
			
        case UIImageOrientationUp: //EXIF = 1
            transform = CGAffineTransformIdentity;
            break;
			
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
			
        case UIImageOrientationDown: //EXIF = 3
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
			
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
			
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
			
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
			
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
			
        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
			
        default:
            //[NSException raise:NSInternalInc*****istencyException format:@"Invalid?image?orientation"];
            break;
    }
	
    UIGraphicsBeginImageContext(bounds.size);
	
    CGContextRef context = UIGraphicsGetCurrentContext();
	
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft)
    {
        CGContextScaleCTM(context, -scaleRatio, scaleRatioheight);
        CGContextTranslateCTM(context, -height, 0);
    }
    else
    {
        CGContextScaleCTM(context, scaleRatio, -scaleRatioheight);
        CGContextTranslateCTM(context, 0, -height);
    }
	
    CGContextConcatCTM(context, transform);
	
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return imageCopy;
}

@end




CMapGraphics2D::CMapGraphics2D(void) : CMapGraphics()
{
	m_imageRoot = nil;
	m_imageScale = nil;
	m_pMapBusiness = NULL;
	m_pView = nil;
	m_imageFlagBegin = nil;
	m_imageFlagEnd = nil;
	m_imageCompass = nil;
}

CMapGraphics2D::~CMapGraphics2D(void)
{
	Release();
}

int CMapGraphics2D::Render(CMapBusiness* pBusiness, UIView* pView, int nDrawOriX, int nDrawOriY)
{
	if (nil == m_imageRoot)
	{
		NSString* strPicPath = [[NSString alloc] initWithUTF8String:m_strMapFilePath.c_str()];
		m_imageRoot = [[UIImage alloc] initWithContentsOfFile:strPicPath]; 
		[strPicPath release];
	}
	
	m_pMapBusiness = pBusiness;
	m_pView = pView;

    CMapBusiness2D* pMapBusiness = (CMapBusiness2D*)pBusiness;
	MAPPOINT pt = pMapBusiness->GetMapOriPt();
	
#if 1
	if (pMapBusiness->IsZoomRateChanged() || m_imageScale == nil)
	{
		if (m_imageScale != nil)
		{
			[m_imageScale release];
		}
		m_imageScale = [m_imageRoot scaleToSize:CGSizeMake(pMapBusiness->GetMapWidth(),
														   pMapBusiness->GetMapHeight())];
		
		//m_imageScale = [m_imageRoot scaleAndRotateImage:pMapBusiness->GetMapWidth() :pMapBusiness->GetMapHeight()];
		
		[m_imageScale retain];
		if (pMapBusiness->IsZoomRateChanged())
		{
			pMapBusiness->SetZoomRateChanged(false);
		}
	}
	
	//carve
//	CGSize subImageSize = CGSizeMake(pMapBusiness->GetScrWidth(), pMapBusiness->GetScrHeight());
//	CGRect subImageRect = CGRectMake(pt.x, pt.y, pMapBusiness->GetScrWidth(), pMapBusiness->GetScrHeight());
//	
//	CGImageRef imageRef = m_imageScale.CGImage;
//	CGImageRef subImageRef = CGImageCreateWithImageInRect(imageRef, subImageRect);
//	
//	UIGraphicsBeginImageContext(subImageSize);
//	CGContextRef context = UIGraphicsGetCurrentContext();
//	
//	CGContextDrawImage(context, subImageRect, subImageRef);
//	UIImage* subImage = [[UIImage alloc] initWithCGImage:subImageRef];
//	UIGraphicsEndImageContext();
//	
//	[subImage drawAtPoint:CGPointMake(0.0, 0.0)];
//	
//	[subImage release];
//	
//	CGImageRelease(subImageRef);
	
	float fRotateDegrees = 0.0f;
	if (m_pMapBusiness->GetNorthHeading() != INVALID_DEGREES)
	{
		fRotateDegrees = m_pMapBusiness->GetNorthHeading();
	}
	
//	CGContextRef context = UIGraphicsGetCurrentContext();
//	CGContextSaveGState(context);
//	CGAffineTransform transform = CGAffineTransformIdentity;
//	CGContextTranslateCTM(context, m_pMapBusiness->GetScrWidth() / 2, m_pMapBusiness->GetScrHeight() / 2);
//	
//	transform = CGAffineTransformRotate(transform, degreesToRadian(fRotateDegrees));
//	CGContextConcatCTM(context, transform);
//	
//	CGContextTranslateCTM(context, -m_pMapBusiness->GetScrWidth() / 2, -m_pMapBusiness->GetScrHeight() / 2);
	[m_imageScale drawAtPoint:CGPointMake(-pt.x, -pt.y)];
	
	
	//[m_imageRoot drawInRect:CGRectMake(-pt.x, -pt.y, pMapBusiness->GetMapWidth(), pMapBusiness->GetMapHeight())];

#else
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	CGContextSaveGState(context);
	
	float fWidthScale = pMapBusiness->GetMapWidth() / m_imageRoot.size.width;
	float fHeightScale = pMapBusiness->GetMapHeight() / m_imageRoot.size.height;
	
	//NSLog(@"fWidthScale:%f fHeightScale:%f", fWidthScale, fHeightScale);
	CGContextTranslateCTM(context, -pt.x, -pt.y);
	CGContextScaleCTM(context, fWidthScale, fHeightScale);
	
	[m_imageRoot drawAtPoint:CGPointMake(0, 0)];
	
	CGContextRestoreGState(context);
#endif
	
	RenderPath();
	
	//CGContextRestoreGState(context);
	
	RenderCompass();
	
    return RE_SUCCESS;
}

int CMapGraphics2D::Init(const string& strMapPath)
{
	Release();
    SetMapPath(strMapPath);
	m_strMapFilePath = strMapPath + "/pic.png";
    return RE_SUCCESS;
}

void CMapGraphics2D::Release()
{	
	NSLog(@"Graphics release");
	if (m_imageRoot != nil)
	{
		[m_imageRoot release];
		m_imageRoot = nil;
	}
	
	if (m_imageScale != nil)
	{
		[m_imageScale release];
		m_imageScale = nil;
	}
	
	if (m_imageFlagBegin != nil)
	{
		[m_imageFlagBegin release];
		m_imageFlagBegin = nil;
	}
	
	if (m_imageFlagEnd != nil)
	{
		[m_imageFlagEnd release];
		m_imageFlagEnd = nil;
	}
	
	if (m_imageCompass != nil)
	{
		[m_imageCompass release];
		m_imageCompass = nil;
	}
}

void CMapGraphics2D::RenderFlagPoint(CGContextRef context, MAPPOINT pt, int nFlagType)
{
	CMapBusiness2D* pMapBusiness = (CMapBusiness2D*)m_pMapBusiness;
	
	if (m_imageFlagBegin == nil)
	{
		m_imageFlagBegin = [[UIImage imageNamed:@"target_begin.png"] retain];
	}
	
	if (m_imageFlagEnd == nil)
	{
		m_imageFlagEnd = [[UIImage imageNamed:@"target_end.png"] retain];
	}
	
	UIImage* imgShow = nil;
	if (FLAG_BEGIN_POINT == nFlagType)
	{
//		int nRadius = pMapBusiness->GetFlagUnit() / 3;
//		
//		pt.x -= nRadius;
//		pt.y -= nRadius;
//		
//		CGRect rc = CGRectMake(pt.x, pt.y, nRadius * 2, nRadius * 2);
//		colorRender = [[UIColor alloc] initWithRed:0.5f
//											 green:0.0f
//											  blue:1.0f
//											 alpha:0.4f];
//		
//		CGContextSetStrokeColorWithColor(context, colorRender.CGColor);
//		CGContextSetFillColorWithColor(context, colorRender.CGColor);
//		
//		CGContextAddEllipseInRect(context, rc);
//		CGContextDrawPath(context, kCGPathEOFillStroke);
		imgShow = m_imageFlagBegin;
	}
	else
	{
		imgShow = m_imageFlagEnd;
	}
	
	
	
	int nOffsetX = pMapBusiness->GetFlagUnit() - pMapBusiness->GetFlagUnit() / 3 * 2;
	int nOffsetY = pMapBusiness->GetFlagUnit() - pMapBusiness->GetFlagUnit() / 4;
	UIImage* imageFlag = [imgShow scaleToSize:CGSizeMake(pMapBusiness->GetFlagUnit(),
																   pMapBusiness->GetFlagUnit())];
	[imageFlag drawAtPoint:CGPointMake(pt.x - nOffsetX, pt.y - nOffsetY)];
	imgShow = nil;
}



void CMapGraphics2D::RenderCompass()
{
	if (NULL == m_pMapBusiness)
	{
		return;
	}
	
	if (m_pMapBusiness->GetNorthHeading() == INVALID_DEGREES)
	{
		return;
	}
	
	if (nil == m_imageCompass)
	{
		m_imageCompass = [[UIImage imageNamed:@"compass.png"] retain];
	}
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGAffineTransform transform = CGAffineTransformIdentity;
	CGContextTranslateCTM(context, 5 + m_imageCompass.size.width / 2, 5 + m_imageCompass.size.height / 2);

	CGPoint ptDrawCompass = CGPointMake(-m_imageCompass.size.width / 2, -m_imageCompass.size.height / 2);
	
	transform = CGAffineTransformRotate(transform, degreesToRadian(m_pMapBusiness->GetNorthHeading()));
	CGContextConcatCTM(context, transform);
	
	[m_imageCompass drawAtPoint:ptDrawCompass];
}

void CMapGraphics2D::RenderPath()
{
	if (!IsShowPath())
	{
		return;
	}
	
	CMapBusiness2D* pMapBusiness = (CMapBusiness2D*)m_pMapBusiness;
	MAPPOINT ptOri = pMapBusiness->GetMapOriPt();

	CGPoint* pPoints = pMapBusiness->CreatePathPoints();
	int nPointsSize = pMapBusiness->GetPathPointsSize();
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	
	CGContextSetLineCap(context, kCGLineCapRound);
	CGFloat arrDash[2];
	arrDash[0] = 0;
	arrDash[1] = 6;

	CGContextSetLineDash(context, 3, arrDash, 2);
	CGContextSetLineJoin(context, kCGLineJoinRound);
	CGContextSetLineWidth(context, 3.0);
	CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:0.8f
															  green:0.1f
															   blue:0.1f
															  alpha:1.0f].CGColor);

	
	CGContextAddLines(context, pPoints, nPointsSize);
	CGContextStrokePath(context);
	
	if (pMapBusiness->IsBeginPtValid())
	{
		MAPPOINT ptBegin = pMapBusiness->GetMapPtByCellPt(pMapBusiness->GetFindBeginPoint());
		ptBegin.x -= ptOri.x;
		ptBegin.y -= ptOri.y;
		RenderFlagPoint(context, ptBegin, FLAG_BEGIN_POINT);
	}
	
	
	
	if (pMapBusiness->IsEndPtValid())
	{
		MAPPOINT ptEnd = pMapBusiness->GetMapPtByCellPt(pMapBusiness->GetFindEndPoint());
		ptEnd.x -= ptOri.x;
		ptEnd.y -= ptOri.y;
		RenderFlagPoint(context, ptEnd, FLAG_END_POINT);
	}
	
	pMapBusiness->ReleasePathPoints(pPoints);
}