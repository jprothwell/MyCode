#include "mapbusiness.h"

CMapBusiness::CMapBusiness(void)
: m_iRootLengthUnit(0)
, m_iLengthUnit(0)
, m_iScrWidth(0)
, m_iScrHeight(0)
, m_bBeginPtValid(false)
, m_bEndPtValid(false)
, m_fNorthHeading(INVALID_DEGREES)
{
}

CMapBusiness::~CMapBusiness(void)
{
}

float CMapBusiness::GetZoomRate()
{
    if (m_iRootLengthUnit > 0)
    {
        return (float)m_iLengthUnit / (float)m_iRootLengthUnit;
    }
    else
    {
        return 0.0f;
    }
}

int  CMapBusiness::RegisterTouchEvent(int nEvent, TouchFunc pFunc)
{
	if (m_mapEvents.find(nEvent) != m_mapEvents.end())
	{
		return RE_FAILED;
	}
	else
	{
		m_mapEvents.insert(make_pair(nEvent, (void*)pFunc));
		return RE_SUCCESS;
	}
}

int CMapBusiness::RespondTouchEvent(int nEvent, CMapObject* pObject, void* pParam)
{
	map<int, void*>::iterator it = m_mapEvents.find(nEvent);
	if (it == m_mapEvents.end())
	{
		return RE_NOT_REGISTER;
	}
	else
	{
		TouchFunc pFunc = (TouchFunc)it->second;
		return pFunc(pObject, pParam);
	}
}

int CMapBusiness::SetBeginPoint(int x, int y)
{
	SetBeginPtValid(true);
	return RE_SUCCESS;
}

int CMapBusiness::SetEndPoint(int x, int y)
{
	SetEndPtValid(true);
	return RE_SUCCESS;
}


