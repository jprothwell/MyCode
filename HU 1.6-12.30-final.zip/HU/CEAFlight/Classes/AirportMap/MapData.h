#pragma once
#import "common.h"

struct MAPCELL
{
    MAPCELL():byValue(0)
    {

    }
    BYTE byValue;
};

class CMapData
{
public:
    CMapData(void);
    ~CMapData(void);

protected:
    MAPCELL*** m_pMatrix;
    int m_iRowNum;
    int m_iColNum;
public:
    void ReleaseMap(void);
    void CreateMap(int iRowNum, int iColNum);
    void SetValue(int iRow, int iCol, MAPCELL* pCell);
    MAPCELL* GetValue(int iRow, int iCol);
    int GetRowNum(void);
    int GetColNum(void);
    void CopyMap(CMapData& mapObj);
    int Init(const string& strFilePath);
};
