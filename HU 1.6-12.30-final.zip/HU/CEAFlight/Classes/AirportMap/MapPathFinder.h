/*
 *  PathFinder.h
 *  CEAFlight
 *
 *  Created by wengyu on 10-12-17.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#pragma once
#include "common.h"
#include "MapData.h"
#include "MapObjManager.h"

#define ENTER_REACH_END 0
#define ENTER_NOT_REACH_END 1

typedef struct tagANODE
	{
		tagANODE()
		{
			nRow = 0;
			nCol = 0;
			f = 0;
			g = 0;
			h = 0;
			pParentNode = NULL;
		}
		int nRow;
		int nCol;
		int f;
		int g;
		int h;
		tagANODE* pParentNode;
	}ANODE, *LPANODE;

class CMapPathFinder
{
public:
	CMapPathFinder();
	virtual ~CMapPathFinder();
	
public:
	
	PropertyAllPtr(m_pMapData, MapData, CMapData*);
	PropertyAllPtr(m_pObjMgr, ObjManager, CMapObjManager*);
	
	int CalcPath(int nBeginRow, int nBeginCol, int nEndRow, int nEndCol,
				 list<CELLPOINT>& lstPath);
				 

	
protected:
    void ReleaseList(list<ANODE*>& lstNode);
    void InsertIntoOpenList(LPANODE pNode);
    void Release(void);
    int CalcGValue(LPANODE pCurNode, LPANODE pObjNode);
    int CalcHValue(LPANODE pNode, int nObjRow, int nObjCol);
    void FindBetterPath(int nRow, int nCol, LPANODE pCurNode);
	CMapObject* GetObjByRowAndCol(int nRow, int nCol, CMapData* pData);
	bool IsPtUsed(CELLPOINT pt);
	int TryToEnterNewCell(int nObjRow, int nObjCol, ANODE* pCurNode);
	int TryToEnterNewCellByOffset(int nObjRowOffset, int nObjColOffset, ANODE* pCurNode);
	
protected:
	PropertyAll(m_ptBegin, BeginPoint, CELLPOINT);
	PropertyAll(m_ptEnd, EndPoint, CELLPOINT);
	
protected:
	
	CMapData* m_pMapData;
	CMapObjManager* m_pObjMgr;
	
    list<ANODE*> m_lstOpen;
    list<ANODE*> m_lstClose;
	list<CELLPOINT> m_lstPtUsed;
	
	CELLPOINT m_ptBegin;
	CELLPOINT m_ptEnd;
};

