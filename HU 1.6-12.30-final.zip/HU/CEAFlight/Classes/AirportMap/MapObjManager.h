#pragma once
#include "MapObject.h"

class CMapObjManager
{
public:
    CMapObjManager(void);
    virtual ~CMapObjManager(void);

protected:
    map<unsigned int, CMapObject*> m_mapObjs;
public:
    int Init(const string& strPath, const string& strInfoPicPath);
    void ReleaseObjs(void);
    CMapObject* GetMapObjectByID(unsigned int nID);
};
