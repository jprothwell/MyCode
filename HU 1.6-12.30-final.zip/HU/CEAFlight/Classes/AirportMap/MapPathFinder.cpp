/*
 *  PathFinder.cpp
 *  CEAFlight
 *
 *  Created by wengyu on 10-12-17.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "MapPathFinder.h"

CMapPathFinder::CMapPathFinder()
: m_pMapData(NULL)
, m_pObjMgr(NULL)
{
}

CMapPathFinder::~CMapPathFinder()
{
}

int CMapPathFinder::TryToEnterNewCell(int nObjRow, int nObjCol, ANODE* pCurNode)
{
	ANODE* pNode = NULL;
	if (nObjCol == m_ptEnd.nCol
		&& nObjRow == m_ptEnd.nRow)
	{
		pNode = new ANODE;
		pNode->nRow = nObjRow;
		pNode->nCol = nObjCol;
		pNode->pParentNode = pCurNode;
		m_lstClose.push_back(pNode);
		return ENTER_REACH_END;
	}
	
	CMapObject* pObj = GetObjByRowAndCol(nObjRow, nObjCol, m_pMapData);
	bool bPtUsed = IsPtUsed(CellPointMake(nObjRow, nObjCol));
	
	if (!pObj->IsBlock() && !bPtUsed)
	{
		pNode = new ANODE;
		pNode->nCol = nObjCol;
		pNode->nRow = nObjRow;
		pNode->pParentNode = pCurNode;
		
		pNode->g = pCurNode->g + CalcGValue(pCurNode, pNode) + pObj->GetMoveValue();
		pNode->h = CalcHValue(pNode, m_ptEnd.nRow, m_ptEnd.nCol);
		pNode->f = pNode->g + pNode->h;
		InsertIntoOpenList(pNode);
		m_lstPtUsed.push_back(CellPointMake(pNode->nRow, pNode->nCol));
	}
	else
	{
		if (bPtUsed)
		{
			FindBetterPath(nObjRow, nObjCol, pCurNode);
		}
	}
	
	return ENTER_NOT_REACH_END;
}

int CMapPathFinder::TryToEnterNewCellByOffset(int nObjRowOffset, int nObjColOffset, ANODE* pCurNode)
{
	int nObjRow = pCurNode->nRow + nObjRowOffset;
	int nObjCol = pCurNode->nCol + nObjColOffset;
	ANODE* pNode = NULL;
	if (nObjCol == m_ptEnd.nCol
		&& nObjRow == m_ptEnd.nRow)
	{
		pNode = new ANODE;
		pNode->nRow = nObjRow;
		pNode->nCol = nObjCol;
		pNode->pParentNode = pCurNode;
		m_lstClose.push_back(pNode);
		return ENTER_REACH_END;
	}
	
	CMapObject* pObj = GetObjByRowAndCol(nObjRow, nObjCol, m_pMapData);
	bool bPtUsed = IsPtUsed(CellPointMake(nObjRow, nObjCol));
	
	CMapObject* pObj1 = GetObjByRowAndCol(pCurNode->nRow + nObjRowOffset, pCurNode->nCol, m_pMapData);
	CMapObject* pObj2 = GetObjByRowAndCol(pCurNode->nRow, pCurNode->nCol + nObjColOffset, m_pMapData);
	
	bool bNotBlock = !pObj->IsBlock() && (!pObj1->IsBlock() || !pObj2->IsBlock());
	
	if (bNotBlock && !bPtUsed)
	{
		pNode = new ANODE;
		pNode->nCol = nObjCol;
		pNode->nRow = nObjRow;
		pNode->pParentNode = pCurNode;
		
		pNode->g = pCurNode->g + CalcGValue(pCurNode, pNode) + pObj->GetMoveValue();
		pNode->h = CalcHValue(pNode, m_ptEnd.nRow, m_ptEnd.nCol);
		pNode->f = pNode->g + pNode->h;
		InsertIntoOpenList(pNode);
		m_lstPtUsed.push_back(CellPointMake(pNode->nRow, pNode->nCol));
	}
	else
	{
		if (bPtUsed && (!pObj1->IsBlock() || !pObj2 ->IsBlock()))
		{
			FindBetterPath(nObjRow, nObjCol, pCurNode);
		}
	}
	
	return ENTER_NOT_REACH_END;
}

int CMapPathFinder::CalcPath(int nBeginRow, int nBeginCol, int nEndRow, int nEndCol,
							 list<CELLPOINT>& lstPath)
{
	SetBeginPoint(CellPointMake(nBeginRow, nBeginCol));
	SetEndPoint(CellPointMake(nEndRow, nEndCol));
	
	Release();
    lstPath.clear();
	
    if (nBeginCol == nEndCol
        && nBeginRow == nEndRow)
    {
        return RE_SUCCESS;
    }
	
	CMapObject* pObj = NULL;
	
	pObj = GetObjByRowAndCol(nEndRow, nEndCol, m_pMapData);
	
    if (!pObj->IsCanLocate())
    {
        return RE_FAILED;
    }
	
	
    LPANODE pNode = new ANODE;
    pNode->nRow = nBeginRow;
    pNode->nCol = nBeginCol;
    InsertIntoOpenList(pNode);
    m_lstPtUsed.push_back(CellPointMake(pNode->nRow, pNode->nCol));
	
	int nObjRow = 0;
	int nObjCol = 0;
	
    while (TRUE)
    {
        if (m_lstOpen.empty())
        {
            Release();
            return RE_FAILED;
        }
		
        LPANODE pCurNode = *m_lstOpen.begin();
        m_lstOpen.pop_front();
		
        //up
        if (pCurNode->nRow - 1 >= 0)
        {
			nObjRow = pCurNode->nRow - 1;
			nObjCol = pCurNode->nCol;
			
			if (ENTER_REACH_END == TryToEnterNewCell(nObjRow, nObjCol, pCurNode))
			{
				break;
			}
        }
		
        //down
        if (pCurNode->nRow + 1 < m_pMapData->GetRowNum())
        {
			nObjRow = pCurNode->nRow + 1;
			nObjCol = pCurNode->nCol;
			
			if (ENTER_REACH_END == TryToEnterNewCell(nObjRow, nObjCol, pCurNode))
			{
				break;
			}
        }
		
        //left
        if (pCurNode->nCol - 1 >= 0)
        {
			nObjRow = pCurNode->nRow;
			nObjCol = pCurNode->nCol - 1;
			
			if (ENTER_REACH_END == TryToEnterNewCell(nObjRow, nObjCol, pCurNode))
			{
				break;
			}
        }
		
        //right
        if (pCurNode->nCol + 1 < m_pMapData->GetColNum())
        {
			nObjRow = pCurNode->nRow;
			nObjCol = pCurNode->nCol + 1;
            if (ENTER_REACH_END == TryToEnterNewCell(nObjRow, nObjCol, pCurNode))
			{
				break;
			}
        }
		
		//leftup
        if (pCurNode->nRow - 1 >= 0 && pCurNode->nCol - 1 >= 0)
        {
            if (ENTER_REACH_END == TryToEnterNewCellByOffset(-1, -1, pCurNode))
			{
				break;
			}
        }
		
        //leftdown
        if (pCurNode->nRow + 1 < m_pMapData->GetRowNum() && pCurNode->nCol - 1 >= 0)
        {
			if (ENTER_REACH_END == TryToEnterNewCellByOffset(1, -1, pCurNode))
			{
				break;
			}
        }
		
        //rightdown
        if (pCurNode->nRow + 1 < m_pMapData->GetRowNum() && pCurNode->nCol + 1 < m_pMapData->GetColNum())
        {
			if (ENTER_REACH_END == TryToEnterNewCellByOffset(1, 1, pCurNode))
			{
				break;
			}
        }
		
        //rightup
        if (pCurNode->nRow - 1 >= 0 && pCurNode->nCol + 1 < m_pMapData->GetColNum())
        {
			if (ENTER_REACH_END == TryToEnterNewCellByOffset(-1, 1, pCurNode))
			{
				break;
			}
        }
		
        m_lstClose.push_back(pCurNode);
    }
	
	
    list<ANODE*>::iterator itEnd = m_lstClose.end();
    --itEnd;
    pNode = *itEnd;
	
    while (pNode != NULL)
    {
        lstPath.push_front(CellPointMake(pNode->nRow, pNode->nCol));
        pNode = pNode->pParentNode;
    }
	
    //stackPath.pop();
    Release();
	
	return RE_SUCCESS;
}

void CMapPathFinder::ReleaseList(list<ANODE*>& lstNode)
{
    for (list<ANODE*>::iterator it = lstNode.begin(); it != lstNode.end(); ++it)
    {
        SAFE_DELETE(*it);
    }
	
    lstNode.clear();
}

void CMapPathFinder::InsertIntoOpenList(LPANODE pNode)
{
    list<LPANODE>::iterator it = m_lstOpen.begin();
    for (; it != m_lstOpen.end(); ++it)
    {
        if ((*it)->f >= pNode->f)
        {
            break;
        }
    }
	
    m_lstOpen.insert(it, pNode);
}

void CMapPathFinder::Release(void)
{
    ReleaseList(m_lstOpen);
    ReleaseList(m_lstClose);
	m_lstPtUsed.clear();
}

void CMapPathFinder::FindBetterPath(int nRow, int nCol, LPANODE pCurNode)
{
    list<ANODE*>::iterator it;
    LPANODE pNode = NULL;
    for (it = m_lstOpen.begin(); it != m_lstOpen.end(); ++it)
    {
        if ((*it)->nCol == nCol && (*it)->nRow == nRow)
        {
            pNode = *it;
            break;
        }
    }
	
    if (pNode == NULL)
    {
        for (it = m_lstClose.begin(); it != m_lstClose.end(); ++it)
        {
            if ((*it)->nCol == nCol && (*it)->nRow == nRow)
            {
                pNode = *it;
                break;
            }
        }
    }
	
    if (pNode != NULL)
    {
        int iG = pNode->g + CalcGValue(pNode, pCurNode);
        if (iG < pCurNode->g)
        {
            pCurNode->pParentNode = pNode;
        }
    }
}

int CMapPathFinder::CalcHValue(LPANODE pNode, int nObjRow, int nObjCol)
{
    int iH = (abs(pNode->nCol - nObjCol) + abs(pNode->nRow - nObjRow)) * 10;
    int iStart = min(pNode->nCol, nObjCol);
    int iEnd = max(pNode->nCol, nObjCol);
	
    int i;
	
    if (pNode->nRow == nObjRow)
    {
        for (i = iStart; i < iEnd; ++i)
        {
			CMapObject* pObj = GetObjByRowAndCol(nObjRow, i, m_pMapData);
			if (pObj != NULL)
            {
				if (pObj->IsBlock())
				{
					iH += 10;
					break;
				}
			}
        }
    }
	
    iStart = min(pNode->nRow, nObjRow);
    iEnd = max(pNode->nRow, nObjRow);
	
    if (pNode->nCol == nObjCol)
    {
        for (i = iStart; i < iEnd; ++i)
        {
			CMapObject* pObj = GetObjByRowAndCol(i, nObjCol, m_pMapData);
			if (pObj != NULL)
            {
				if (pObj->IsBlock())
				{
					iH += 10;
					break;
				}
			}
        }
    }
    return iH;
}

int CMapPathFinder::CalcGValue(LPANODE pCurNode, LPANODE pObjNode)
{
    if (abs(pCurNode->nCol - pObjNode->nCol) + abs(pCurNode->nRow - pObjNode->nRow) == 2)
    {
        return 14;
    }
    else if (abs(pCurNode->nCol - pObjNode->nCol) + abs(pCurNode->nRow - pObjNode->nRow) == 1)
    {
        return 10;
    }
    else
    {
        return 0;
    }
}

CMapObject* CMapPathFinder::GetObjByRowAndCol(int nRow, int nCol, CMapData* pData)
{
	MAPCELL* pCell = pData->GetValue(nRow, nCol);
	
	if (NULL == pCell)
	{
		return NULL;
	}
	
	CMapObject* pObj = m_pObjMgr->GetMapObjectByID(pCell->byValue);
	return pObj;
}

bool CMapPathFinder::IsPtUsed(CELLPOINT pt)
{
	for (list<CELLPOINT>::iterator it = m_lstPtUsed.begin();
		 it != m_lstPtUsed.end(); ++it)
	{
		if (it->nRow == pt.nRow
			&& it->nCol == pt.nCol)
		{
			return true;
		}
	}
	
	return false;
}