#include "mapgraphics.h"

CMapGraphics::CMapGraphics(void)
: m_bShowPath(false)
{
}

CMapGraphics::~CMapGraphics(void)
{
}
