#pragma once
#include "MapBusiness2D.h"

#define MAP_BUSINESS_2D "CMapBusiness2D"

class CFactoryMapBusiness : public CObjectFactory<CMapBusiness>
{
public:
    CFactoryMapBusiness(void);
    virtual ~CFactoryMapBusiness(void);
};
