/*
 *  MapLocManager.h
 *  CEAFlight
 *
 *  Created by wengyu on 10-12-22.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#pragma once
#include "common.h"

class CMapLocManager
{
public:
	CMapLocManager();
	~CMapLocManager();
	
	int Init(const string& strXmlPath);
	
	int GetLocationPtByID(int nID, CELLPOINT& ptGet);
protected:
	map<int, CELLPOINT> m_mapLocations;
};