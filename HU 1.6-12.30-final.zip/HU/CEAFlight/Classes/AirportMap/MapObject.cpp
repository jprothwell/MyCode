#include "mapobject.h"

CMapObject::CMapObject(void)
: m_nID(0)
, m_bBlock(false)
, m_bShowTip(false)
, m_bCanLocate(false)
{
}

CMapObject::~CMapObject(void)
{
}

int CMapObject::InitWithXmlNode(TiXmlElement* pElem)
{
    try
    {
        SetObjID(GetElemValueInt(pElem, "id"));
        SetObjName(GetElemValue(pElem, "name"));
        SetObjInfo(GetElemValue(pElem, "info"));
        SetBlock(GetElemValueInt(pElem, "block"));
		SetCanLocate(GetElemValueInt(pElem, "canlocate"));
        SetShowTip(GetElemValueInt(pElem, "showtip"));  
		SetPicName(GetElemValue(pElem, "pic"));
		SetMoveValue(GetElemValueInt(pElem, "movevalue"));
    }

    catch (...)
    {
        return RE_FAILED;
    }

    return RE_SUCCESS;
}