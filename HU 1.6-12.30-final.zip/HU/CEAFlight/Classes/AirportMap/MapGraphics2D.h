#pragma once
#include "mapgraphics.h"

@interface UIImage(scale)

- (UIImage*) scaleToSize:(CGSize)sizeMap;

@end

#define FLAG_BEGIN_POINT 0
#define FLAG_END_POINT 1

class CMapGraphics2D :
    public CMapGraphics
{
public:
    CMapGraphics2D(void);
    virtual ~CMapGraphics2D(void);

public:
    virtual int Render(CMapBusiness* pBusiness, UIView* pView, int nDrawOriX, int nDrawOriY);
    virtual int Init(const string& strMapPath);
	virtual void Release();
	
protected:
	void RenderPath();
	void RenderCompass();
	void RenderFlagPoint(CGContextRef context, MAPPOINT pt, int nFlagType);
	
protected:
	string m_strMapFilePath;
	UIImage* m_imageRoot;
	UIImage* m_imageScale;
	UIImage* m_imageFlagEnd;
	UIImage* m_imageFlagBegin;
	UIImage* m_imageCompass;
	CMapBusiness* m_pMapBusiness;
	UIView* m_pView;
	
};
