#include <list>
#include <map>
#include <string>
#include "CGPointUtils.h"
#include "XMLParser.h"
using namespace std;

#define RE_SUCCESS 0
#define RE_FAILED -1

#define PropertySet(Variable, FuncName, VariableType) \
    void Set##FuncName(const VariableType& value){Variable = value;}\

#define PropertyGet(Variable, FuncName, VariableType) \
    VariableType Get##FuncName(){return Variable;}\

#define  PropertyAll(Variable, FuncName, VariableType) \
    PropertySet(Variable, FuncName, VariableType);\
    PropertyGet(Variable, FuncName, VariableType);\

#define  PropertyAllBool(Variable, FuncName, VariableType) \
    PropertySet(Variable, FuncName, VariableType);\
    VariableType Is##FuncName(){return Variable;}\

#define  PropertyAllPtr(Variable, FuncName, VariableType) \
    void Set##FuncName(VariableType value){Variable = value;}\
    PropertyGet(Variable, FuncName, VariableType);\

#define SAFE_DELETE(p) \
    if (p != NULL)\
{\
    delete p;\
    p = NULL;\
}

#define SAFE_DELETE_ARRAY(p) \
    if (p != NULL)\
{\
    delete [] p;\
    p = NULL;\
}

#define INVALID_DEGREES 9999.0f

#define degreesToRadian(x) (M_PI * x / 180.0)

typedef unsigned char BYTE;

template <class T> class CObjectFactory
	{
		typedef T* (*CreateFunc)();
	public:
		bool Register(const string& strFuncName, CreateFunc pFunc)
		{
			m_mapCreateFunc.insert(make_pair(strFuncName, (void*)pFunc));
			return true;
		}
		
		T* Create(const string& strFuncName)
		{
			map<string, void*>::iterator it = m_mapCreateFunc.find(strFuncName);
			if (it != m_mapCreateFunc.end())
			{
				CreateFunc pFunc = (CreateFunc)it->second;
				return pFunc();
			}
			else
			{
				return NULL;
			}
		}
	protected:
		map<string, void*> m_mapCreateFunc;
	};

inline string GetElemValue(TiXmlElement* pElem, const string& strChildName)
{
    string strValue;
   
    const char* szValue = pElem->FirstChildElement(strChildName.c_str())->GetText();
    if (NULL == szValue)
    {
        strValue = "";
    }
    else
    {
        strValue = szValue;
    }

    return strValue;
}

inline int GetElemValueInt(TiXmlElement* pElem, const string& strChildName)
{
    string strValue = GetElemValue(pElem, strChildName);
    return atoi(strValue.c_str());
}

struct MAPPOINT
{
    MAPPOINT():x(0), y(0){}
    int x;
    int y;
};

inline MAPPOINT MapPointMake(int x, int y)
{
	MAPPOINT pt;
	pt.x = x;
	pt.y = y;
	return pt;
}

struct CELLPOINT
{
	CELLPOINT()
	{
		nRow = 0;
		nCol = 0;
	}
	int nRow;
	int nCol;
};

inline CELLPOINT CellPointMake(int nRow, int nCol)
{
	CELLPOINT pt;
	pt.nRow = nRow;
	pt.nCol = nCol;
	return pt;
}

inline void ParseString(list<string>& lstStrings, const string& strSrc, char chTok)
{
	int nTotalIndex = 0;
	int nTempIndex = 0;
	int nTotalSize = strSrc.size();
	
    lstStrings.clear();
    char* szParse = new char [nTotalSize + 1];
	strcpy(szParse, strSrc.c_str());
	
	int nTempSize = 256;
	char* szTempValue = new char [nTempSize];
	memset(szTempValue, 0, nTempSize);
	
	for (nTotalIndex = 0; nTotalIndex < nTotalSize; ++nTotalIndex)
	{
		char cCurValue = szParse[nTotalIndex];
		if (cCurValue == chTok)
		{
			if (nTempIndex > 0)
			{
				lstStrings.push_back(szTempValue);
				nTempIndex = 0;
				memset(szTempValue, 0, nTempSize);
			}
		}
		else
		{
			szTempValue[nTempIndex] = cCurValue;
			++nTempIndex;
		}
	}
	
	if (nTempIndex > 0)
	{
		lstStrings.push_back(szTempValue);
	}
	
	SAFE_DELETE_ARRAY(szParse);
	SAFE_DELETE_ARRAY(szTempValue);
}
