#pragma once
#include "MapGraphics2D.h"

#define MAP_GRAPHICS_2D "CMapGraphics2D"

class CFactoryMapGraphics : public CObjectFactory<CMapGraphics>
{
public:
    CFactoryMapGraphics(void);
    virtual ~CFactoryMapGraphics(void);
};
