#include "mapbusiness2d.h"

CMapBusiness2D::CMapBusiness2D(void) : CMapBusiness()
, m_bZoomRateChanged(false)
, m_iFlagUnit(0)
, m_iZoomStep(0)
{
}

CMapBusiness2D::~CMapBusiness2D(void)
{
}

int CMapBusiness2D::Press(int x, int y, int nTouchEvent, void* pParam)
{
	x += m_ptOri.x;
	y += m_ptOri.y;
    int nRow = GetRowFromPixel(y);
    int nCol = GetColFromPixel(x);
	
	NSLog(@"%d %d %d", nRow, nCol, m_mapData.GetValue(nRow, nCol)->byValue);
    MAPCELL* pCell = m_mapData.GetValue(nRow, nCol);

    if (NULL == pCell)
    {
        return RE_FAILED;
    }

    CMapObject* pObj = m_mapObjMgr.GetMapObjectByID(pCell->byValue);
	
	if (NULL == pObj)
	{
		return RE_FAILED;
	}
	
	return RespondTouchEvent(nTouchEvent, pObj, pParam);
}

int CMapBusiness2D::Move(int iOffsetX, int iOffsetY)
{
    m_ptOri.x += iOffsetX;
    m_ptOri.y += iOffsetY;

    if (m_ptOri.x < 0)
    {
        m_ptOri.x = 0;
    }

    int nWidthLimit = 0;
	
    if (GetMapWidth() < GetScrWidth())
    {
        nWidthLimit = 0;
    }
    else
    {
        nWidthLimit = GetMapWidth() - GetScrWidth();
    }
    if (m_ptOri.x >= nWidthLimit)
    {
        m_ptOri.x = nWidthLimit;
    }

    if (m_ptOri.y < 0)
    {
        m_ptOri.y = 0;
    }

    int nHeightLimit = 0;
    if (GetMapHeight() < GetScrHeight())
    {
        nHeightLimit = 0;
    }
    else
    {
        nHeightLimit = GetMapHeight() - GetScrHeight();
    }

    if (m_ptOri.y >= nHeightLimit)
    {
        m_ptOri.y = nHeightLimit;
    }
	
    return RE_SUCCESS;
}

int CMapBusiness2D::Zoom(int nZoomOperaion)
{
    int iOffset = GetLengthUnit();
    if (ZOOM_IN == nZoomOperaion)
    {
        if (m_iLengthUnit < m_iRootLengthUnit * 1.5)
        {
            m_iLengthUnit += GetZoomStep();
        }
    }
    else
    {
        if (m_iLengthUnit > m_iRootLengthUnit * 0.2)
        {
			if (m_iLengthUnit - GetZoomStep() > 0)
            {
				m_iLengthUnit -= GetZoomStep();
			}
			
			NSLog(@"MapWidth:%d ScrWidth:%d MapHeight:%d ScrHeight:%d", 
				  GetMapWidth(), GetScrWidth(), GetMapHeight(), GetScrHeight());
            if (GetMapWidth() < GetScrWidth()
             || GetMapHeight() < GetScrHeight())
            {
                m_iLengthUnit += GetZoomStep();
            }
        }
    }

    iOffset -= GetLengthUnit();

    m_ptOri.x -= iOffset * GetColFromPixel(m_ptOri.x + GetScrWidth() / 2);
    m_ptOri.y -= iOffset * GetRowFromPixel(m_ptOri.y + GetScrHeight() / 2);
    if (m_ptOri.x < 0)
    {
        m_ptOri.x = 0;
    }

    if (m_ptOri.y < 0)
    {
        m_ptOri.y = 0;
    }

    if (m_ptOri.x + GetScrWidth() > GetMapWidth())
    {
        m_ptOri.x = GetMapWidth() - GetScrWidth();
    }

    if (m_ptOri.y + GetScrHeight() > GetMapHeight())
    {
        m_ptOri.y = GetMapHeight() - GetScrHeight();
    }

	if (iOffset != 0)
	{
		SetZoomRateChanged(true);
	}
	
    return RE_SUCCESS;
}

int CMapBusiness2D::Init(const string& strMapPath, int nScrWidth, int nScrHeight)
{
	
    SetMapPath(strMapPath);
    SetScrWidth(nScrWidth);
    SetScrHeight(nScrHeight);
	
	//ShowMsgEx([NSString stringWithUTF8String:strMapPath.c_str()]);
    if (m_mapData.Init(GetMapPath() + "/base.xml") != RE_SUCCESS)
    {
		NSLog(@"Init map data failed");
        return RE_FAILED;
    }

    if (m_mapObjMgr.Init(GetMapPath() + "/object.xml", GetMapPath() + "/InfoPic") != RE_SUCCESS)
    {
		NSLog(@"InitObjs failed");
        return RE_FAILED;
    }
	
	if (m_mapLocMgr.Init(GetMapPath() + "/location.xml") != RE_SUCCESS)
	{
		NSLog(@"Init map loc failed");
		return RE_FAILED;
	}

    if (ReadConfigInfo() != RE_SUCCESS)
    {
		NSLog(@"Init conift failed");
        return RE_FAILED;
    }

	m_pathFinder.SetMapData(&m_mapData);
	m_pathFinder.SetObjManager(&m_mapObjMgr);
	
    return RE_SUCCESS;
}

int CMapBusiness2D::ReadConfigInfo()
{
    TiXmlDocument doc;
    string strPath = GetMapPath() + "/config.xml";
    if (!doc.LoadFile(strPath.c_str()))
    {
        return RE_FAILED;
    }

    try
    {
        TiXmlElement* pElem = doc.RootElement();
        SetLengthUnit(GetElemValueInt(pElem, "LengthUnit"));
		SetFlagUnit(GetElemValueInt(pElem, "FlagUnit"));
		SetZoomStep(GetElemValueInt(pElem, "ZoomStep"));
        m_iRootLengthUnit = GetLengthUnit();
		SetLengthUnit(GetElemValueInt(pElem, "InitLengthUnit"));
		NSLog(@"LengthUnit:%d", GetElemValueInt(pElem, "InitLengthUnit"));
    }
    catch (...)
    {
        return RE_FAILED;
    }
    return RE_SUCCESS;
}

int CMapBusiness2D::GetMapRows()
{
    return m_mapData.GetRowNum();
}

int CMapBusiness2D::GetMapCols()
{
    return m_mapData.GetColNum();
}

int CMapBusiness2D::GetMapWidth()
{
    return m_mapData.GetColNum() * GetLengthUnit();
}

int CMapBusiness2D::GetMapHeight()
{
    return m_mapData.GetRowNum() * GetLengthUnit();
}

int CMapBusiness2D::GetRowFromPixel(int nPosY)
{
    if (GetLengthUnit() > 0)
    {
        return nPosY / GetLengthUnit();
    }
    else
    {
        return RE_FAILED;
    }
}

int CMapBusiness2D::GetColFromPixel(int nPosX)
{
    if (GetLengthUnit() > 0)
    {
        return nPosX / GetLengthUnit();
    }
    else
    {
        return RE_FAILED;
    }
}

CGPoint* CMapBusiness2D::CreatePathPoints()
{
	if (m_lstPathPoints.empty())
	{
		return NULL;
	}
	
	CGPoint* pPathPoints = new CGPoint[m_lstPathPoints.size()];
	
	int nCount = 0;
	for (list<CELLPOINT>::iterator it = m_lstPathPoints.begin(); it != m_lstPathPoints.end(); ++it)
	{
		MAPPOINT ptMap = GetMapPtByCellPt(*it);
		ptMap.x -= m_ptOri.x;
		ptMap.y -= m_ptOri.y;
		pPathPoints[nCount] = CGPointMake(ptMap.x, ptMap.y);
		++nCount;
	}
	
//	if (GetPathPointsSize() > 1)
//	{
//		pPathPoints[0].x = GetFindBeginPoint().x - m_ptOri.x;
//		pPathPoints[0].y = GetFindBeginPoint().y - m_ptOri.y;
//		pPathPoints[GetPathPointsSize() - 1].x = GetFindEndPoint().x - m_ptOri.x;
//		pPathPoints[GetPathPointsSize() - 1].y = GetFindEndPoint().y - m_ptOri.y;
//	}
	return pPathPoints;
}

int CMapBusiness2D::GetPathPointsSize()
{
	return m_lstPathPoints.size();
}

void CMapBusiness2D::ReleasePathPoints(CGPoint* pPoints)
{
	SAFE_DELETE_ARRAY(pPoints);
}

int CMapBusiness2D::CalcPath()
{
	if (!IsBeginPtValid())
	{
		return RE_ERROR_BEGINPT_NOT_SET;
	}
	
	if (!IsEndPtValid())
	{
		return RE_ERROR_ENDPT_NOT_SET;
	}
	
	return m_pathFinder.CalcPath(m_ptFindBegin.nRow, 
								 m_ptFindBegin.nCol,
								 m_ptFindEnd.nRow, 
								 m_ptFindEnd.nCol,
								 m_lstPathPoints);
}

MAPPOINT CMapBusiness2D::GetMapPtByCellPt(CELLPOINT ptCell)
{
	MAPPOINT ptMap;
	int nLengthUnit = GetLengthUnit();
	ptMap.x = ptCell.nCol * nLengthUnit + nLengthUnit / 2;
	ptMap.y = ptCell.nRow * nLengthUnit + nLengthUnit / 2;
	return ptMap;
}

void CMapBusiness2D::ClearPath()
{
	m_lstPathPoints.clear();
}

int CMapBusiness2D::SetBeginPoint(int x, int y)
{
	x += m_ptOri.x;
	y += m_ptOri.y;
	
	int nRow = GetRowFromPixel(y);
    int nCol = GetColFromPixel(x);
    MAPCELL* pCell = m_mapData.GetValue(nRow, nCol);
	
	if (NULL == pCell)
	{
		return RE_FAILED;
	}
	
	CMapObject* pObj = m_mapObjMgr.GetMapObjectByID(pCell->byValue);
	if (NULL == pObj)
	{
		return RE_FAILED;
	}
	
	if (pObj->IsCanLocate())
	{
		m_ptFindBegin.nRow = nRow;
		m_ptFindBegin.nCol = nCol;
		CMapBusiness::SetBeginPoint(x, y);
		
		NSLog(@"Begin:%d %d", nRow, nCol);
		return RE_SUCCESS;
	}
	else
	{
		return RE_FAILED;
	}
}

int CMapBusiness2D::SetEndPoint(int x, int y)
{
	x += m_ptOri.x;
	y += m_ptOri.y;
	
	int nRow = GetRowFromPixel(y);
    int nCol = GetColFromPixel(x);
    MAPCELL* pCell = m_mapData.GetValue(nRow, nCol);
	
	if (NULL == pCell)
	{
		return RE_FAILED;
	}
	
	CMapObject* pObj = m_mapObjMgr.GetMapObjectByID(pCell->byValue);
	
	if (NULL == pObj)
	{
		return RE_FAILED;
	}
	
	if (pObj->IsCanLocate())
	{
		m_ptFindEnd.nRow = nRow;
		m_ptFindEnd.nCol = nCol;
		CMapBusiness::SetEndPoint(x, y);
		
		NSLog(@"End:%d %d", nRow, nCol);
		return RE_SUCCESS;
	}
	else
	{
		return RE_FAILED;
	}
}

int CMapBusiness2D::SetPathManually(int nBeginRow, int nBeginCol, int nEndRow, int nEndCol)
{
	SetBeginPtValid(true);
	SetEndPtValid(true);
	
	m_ptFindBegin.nRow = nBeginRow;
	m_ptFindBegin.nCol = nBeginCol;
	
	m_ptFindEnd.nRow = nEndRow;
	m_ptFindEnd.nCol = nEndCol;
	
	return CalcPath();
}

int CMapBusiness2D::SetPath(int nFromLocID, int nDestLocID)
{
	CELLPOINT ptFrom;
	CELLPOINT ptTo;
	if (m_mapLocMgr.GetLocationPtByID(nFromLocID, ptFrom) != RE_SUCCESS)
	{
		return RE_FAILED;
	}
	
	if (m_mapLocMgr.GetLocationPtByID(nDestLocID, ptTo) != RE_SUCCESS)
	{
		return RE_FAILED;
	}
	
	return SetPathManually(ptFrom.nRow, ptFrom.nCol, ptTo.nRow, ptTo.nCol);
}
