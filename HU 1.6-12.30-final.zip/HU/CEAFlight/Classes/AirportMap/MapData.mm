#include "mapdata.h"

CMapData::CMapData(void)
{
    m_pMatrix = NULL;
    m_iRowNum = 0;
    m_iColNum = 0;
}

CMapData::~CMapData(void)
{
    ReleaseMap();
}

void CMapData::ReleaseMap(void)
{
    for (int i = 0; i < m_iRowNum; ++i)
    {
        for (int j = 0; j < m_iColNum; ++j)
        {
            SAFE_DELETE(m_pMatrix[i][j]);
        }
        SAFE_DELETE_ARRAY(m_pMatrix[i]);
    }

    SAFE_DELETE_ARRAY(m_pMatrix);
    m_iRowNum = 0;
    m_iColNum = 0;
}

void CMapData::CreateMap(int iRowNum, int iColNum)
{
    m_iRowNum = iRowNum;
    m_iColNum = iColNum;
    m_pMatrix = new MAPCELL**[iRowNum];
    for (int iRow = 0; iRow < iRowNum; ++iRow)
    {
        m_pMatrix[iRow] = new MAPCELL*[iColNum];
        for (int iCol = 0; iCol < iColNum; ++iCol)
        {
            m_pMatrix[iRow][iCol] = new MAPCELL;
        }
    }
}

void CMapData::SetValue(int iRow, int iCol, MAPCELL* pCell)
{
    m_pMatrix[iRow][iCol]->byValue = pCell->byValue;
}

MAPCELL* CMapData::GetValue(int iRow, int iCol)
{
    return m_pMatrix[iRow][iCol];
}

int CMapData::Init(const string& strFilePath)
{
    ReleaseMap();
    TiXmlDocument doc;
    if (!doc.LoadFile(strFilePath.c_str(), TIXML_DEFAULT_ENCODING))
    {
        return RE_FAILED;
    }

    TiXmlElement* pElem = doc.RootElement()->FirstChildElement("ROW");
    string strMaxLenRow;
	string strRow;
    for (; pElem != NULL; pElem = pElem->NextSiblingElement())
    {
        ++m_iRowNum;
        strRow = pElem->GetText();
        if (strRow.length() > strMaxLenRow.length())
        {
            strMaxLenRow = strRow;
        }
    }

    list<string> lstStrs;
    ParseString(lstStrs, strMaxLenRow, ' ');
    m_iColNum = lstStrs.size();
	
    CreateMap(m_iRowNum, m_iColNum);
	
    int iCurRow = 0;
    int iCurCol = 0;
    for (pElem = doc.RootElement()->FirstChildElement("ROW"); pElem != NULL; pElem = pElem->NextSiblingElement())
    {
        strRow = pElem->GetText();
		
        ParseString(lstStrs, strRow, ' ');
        list<string>::iterator it = lstStrs.begin();

        for (iCurCol = 0; iCurCol < lstStrs.size(); ++iCurCol)
        {
            MAPCELL cell;
            cell.byValue = atoi(it->c_str());
            SetValue(iCurRow, iCurCol, &cell);
            ++it;
        }

        ++iCurRow;
    }
	
    return RE_SUCCESS;
}

void CMapData::CopyMap(CMapData& mapObj)
{
    ReleaseMap();
    CreateMap(mapObj.GetRowNum(), mapObj.GetColNum());
    for (int iRow = 0; iRow < GetRowNum(); ++iRow)
    {
        for (int iCol = 0; iCol < GetColNum(); ++iCol)
        {
            SetValue(iRow, iCol, mapObj.GetValue(iRow, iCol));
        }
    }
}

int CMapData::GetRowNum(void)
{
    return m_iRowNum;
}

int CMapData::GetColNum(void)
{
    return m_iColNum;
}



