#pragma once
#include "common.h"

class CMapObject
{
public:
    CMapObject(void);
    ~CMapObject(void);

    int InitWithXmlNode(TiXmlElement* pElem);

public:
    PropertyAll(m_nID, ObjID, unsigned int);
	PropertyAll(m_nMoveValue, MoveValue, unsigned int);
    PropertyAll(m_strName, ObjName, string);
    PropertyAll(m_strInfo, ObjInfo, string);
	PropertyAll(m_strInfoPicName, PicName, string);
    PropertyAllBool(m_bBlock, Block, bool);
    PropertyAllBool(m_bShowTip, ShowTip, bool);
	PropertyAllBool(m_bCanLocate, CanLocate, bool);

protected:
    unsigned int m_nID;
	unsigned int m_nMoveValue;
    string m_strName;
    string m_strInfo;
	string m_strInfoPicName;
    bool m_bBlock;
    bool m_bShowTip;
	bool m_bCanLocate;
};
