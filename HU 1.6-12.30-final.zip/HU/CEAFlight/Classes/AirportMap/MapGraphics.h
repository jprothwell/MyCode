#pragma once
#include "common.h"


class CMapBusiness;

class CMapGraphics
{
public:
    CMapGraphics(void);
    virtual ~CMapGraphics(void);

public:
    virtual int Init(const string& strMapPath) = 0;
    virtual int Render(CMapBusiness* pBusiness, UIView* pView, int nDrawOriX, int nDrawOriY) = 0;
	virtual void Release(){}

public:
    PropertyAll(m_mapDirPath, MapPath, string);
	PropertyAllBool(m_bShowPath, ShowPath, bool);

protected:
    string m_mapDirPath;
	bool m_bShowPath;
};
