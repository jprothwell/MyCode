/*
 *  MapLocManager.cpp
 *  CEAFlight
 *
 *  Created by wengyu on 10-12-22.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "MapLocManager.h"

CMapLocManager::CMapLocManager()
{
}

CMapLocManager::~CMapLocManager()
{
}

int CMapLocManager::Init(const string& strXmlPath)
{
	m_mapLocations.clear();
    TiXmlDocument doc;
    if (!doc.LoadFile(strXmlPath.c_str(), TIXML_ENCODING_UTF8))
    {
        return RE_FAILED;
    }
	
    try 
    {
        TiXmlElement* pElem = doc.RootElement()->FirstChildElement("loc");
        for (; pElem != NULL; pElem = pElem->NextSiblingElement())
        {
            int nID = GetElemValueInt(pElem, "id");
			CELLPOINT pt;
			pt.nRow = GetElemValueInt(pElem, "row");
			pt.nCol = GetElemValueInt(pElem, "col");
			m_mapLocations.insert(make_pair(nID, pt));
        }
    }
    catch (...)
    {
        m_mapLocations.clear();
        return RE_FAILED;
    }
	
    return RE_SUCCESS;
}

int CMapLocManager::GetLocationPtByID(int nID, CELLPOINT& ptGet)
{
	map<int, CELLPOINT>::iterator it = m_mapLocations.find(nID);
	if (it == m_mapLocations.end())
	{
		return RE_FAILED;
	}
	else
	{
		ptGet = it->second;
		return RE_SUCCESS;
	}
}