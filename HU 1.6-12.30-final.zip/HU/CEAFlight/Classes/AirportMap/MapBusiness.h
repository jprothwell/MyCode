#pragma once
#import "common.h"
#include "MapObjManager.h"

#define ZOOM_IN 0
#define ZOOM_OUT 1

#define RE_NOT_REGISTER 2

class CMapBusiness
{
public:
    CMapBusiness(void);
    virtual ~CMapBusiness(void);

    virtual int Init(const string& strMapPath, int nScrWidth, int nScrHeight) = 0;
    virtual int Move(int iOffsetX, int iOffsetY) = 0;
    virtual int Zoom(int nZoomOperaion) = 0;
    virtual int Press(int x, int y, int nTouchEvent, void* pParam = NULL) = 0;
	virtual int CalcPath(){return RE_SUCCESS;};
	virtual void ClearPath(){};
	virtual int SetBeginPoint(int x, int y);
	virtual int SetEndPoint(int x, int y);
	virtual int SetPath(int nFromLocID, int nDestLocID){return RE_SUCCESS;}
	virtual void Release(){}
	
public:
    PropertyAll(m_mapDirPath, MapPath, string);
    PropertyAll(m_iScrWidth, ScrWidth, int);
    PropertyAll(m_iScrHeight, ScrHeight, int);
    PropertyAll(m_iLengthUnit, LengthUnit, int);
	PropertyAll(m_fNorthHeading, NorthHeading, float);
	PropertyGet(m_ptOri, MapOriPt, MAPPOINT);
	PropertyGet(m_ptFindBegin, FindBeginPoint, CELLPOINT);
	PropertyGet(m_ptFindEnd, FindEndPoint, CELLPOINT);
	PropertyGet(m_iRootLengthUnit, RootLengthUnit, int);
	PropertyAllBool(m_bBeginPtValid, BeginPtValid, bool);
	PropertyAllBool(m_bEndPtValid, EndPtValid, bool);

    float GetZoomRate();
	
	typedef int (*TouchFunc)(CMapObject* pObject, void* pParam);
	int RegisterTouchEvent(int nEvent, TouchFunc pFunc);
	int RespondTouchEvent(int nEvent, CMapObject* pObject, void* pParam);
    
protected:
	map<int, void*> m_mapEvents;
    int m_iLengthUnit;
    int m_iRootLengthUnit;
    string m_mapDirPath;
    int m_iScrWidth;
    int m_iScrHeight;
	MAPPOINT m_ptOri;
	CELLPOINT m_ptFindBegin;
	CELLPOINT m_ptFindEnd;
	bool m_bBeginPtValid;
	bool m_bEndPtValid;
	float m_fNorthHeading;
};
