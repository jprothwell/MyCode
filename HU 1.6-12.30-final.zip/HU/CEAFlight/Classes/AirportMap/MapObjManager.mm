#include "mapobjmanager.h"

CMapObjManager::CMapObjManager(void)
{
}

CMapObjManager::~CMapObjManager(void)
{
    ReleaseObjs();
}

int CMapObjManager::Init(const string& strPath, const string& strInfoPicPath)
{
    ReleaseObjs();
    TiXmlDocument doc;
    if (!doc.LoadFile(strPath.c_str(), TIXML_ENCODING_UTF8))
    {
		NSLog(@"Init obj xml failed");
        return RE_FAILED;
    }

    try 
    {
        TiXmlElement* pElem = doc.RootElement()->FirstChildElement("Object");
        for (; pElem != NULL; pElem = pElem->NextSiblingElement())
        {
            CMapObject* pObj = new CMapObject;
            if (pObj->InitWithXmlNode(pElem) != RE_SUCCESS)
            {
                SAFE_DELETE(pObj);
            }
            else
            {
				if (!pObj->GetPicName().empty())
				{
					pObj->SetPicName(strInfoPicPath + '/' + pObj->GetPicName());
				}
				
				m_mapObjs.insert(make_pair(pObj->GetObjID(), pObj));
            }
        }
    }
    catch (...)
    {
		NSLog(@"Read obj failed");
        ReleaseObjs();
        return RE_FAILED;
    }

    return RE_SUCCESS;
}

void CMapObjManager::ReleaseObjs(void)
{
    for (map<unsigned int, CMapObject*>::iterator it = m_mapObjs.begin(); it != m_mapObjs.end();
        ++it)
    {
        SAFE_DELETE(it->second);
    }

    m_mapObjs.clear();
}

CMapObject* CMapObjManager::GetMapObjectByID(unsigned int nID)
{
    map<unsigned int, CMapObject*>::iterator it = m_mapObjs.find(nID);
    if (it != m_mapObjs.end())
    {
        return it->second;
    }
    else
    {
        return NULL;
    }
}
