#pragma once
#include "mapbusiness.h"
#include "MapData.h"
#include "MapPathFinder.h"
#include "MapLocManager.h"

#define RE_ERROR_BEGINPT_NOT_SET 3
#define RE_ERROR_ENDPT_NOT_SET 4

class CMapBusiness2D :
    public CMapBusiness
{
public:
    CMapBusiness2D(void);
    virtual ~CMapBusiness2D(void);

public:
    virtual int Move(int iOffsetX, int iOffsetY);
    virtual int Zoom(int nZoomOperaion);
    virtual int Init(const string& strMapPath, int nScrWidth, int nScrHeight);
    virtual int Press(int x, int y, int nTouchEvent, void* pParam = NULL);
	virtual int CalcPath();
	virtual void ClearPath();
	virtual int SetBeginPoint(int x, int y);
	virtual int SetEndPoint(int x, int y);
	virtual int SetPath(int nFromLocID, int nDestLocID);

    int GetMapRows();
    int GetMapCols();
    int GetMapWidth();
    int GetMapHeight();
    int GetRowFromPixel(int nPosY);
    int GetColFromPixel(int nPosX);
	CGPoint* CreatePathPoints();
	void ReleasePathPoints(CGPoint* pPoints);
	int GetPathPointsSize();
	MAPPOINT GetMapPtByCellPt(CELLPOINT ptCell);
	
	PropertyAllBool(m_bZoomRateChanged, ZoomRateChanged, bool);
	PropertyAll(m_iFlagUnit, FlagUnit, int);
	PropertyAll(m_iZoomStep, ZoomStep, int);

protected:
    int ReadConfigInfo();
	int SetPathManually(int nBeginRow, int nBeginCol, int nEndRow, int nEndCol);

protected:
    CMapData m_mapData;
    CMapObjManager m_mapObjMgr;
	CMapPathFinder m_pathFinder;
	CMapLocManager m_mapLocMgr;
	list<CELLPOINT> m_lstPathPoints;
	bool m_bZoomRateChanged;
	int m_iFlagUnit;
	int m_iZoomStep;
};
