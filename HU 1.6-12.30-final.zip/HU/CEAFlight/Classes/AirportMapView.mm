//
//  AirportMapView.m
//  CEAFlight
//
//  Created by wengyu on 10-12-16.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AirportMapView.h"
#import "common.h"

CGFloat GetDistanceBetweenPoints (CGPoint first, CGPoint second) {
	CGFloat deltaX = second.x - first.x;
	CGFloat deltaY = second.y - first.y;
	return sqrt(deltaX*deltaX + deltaY*deltaY );
};

@implementation AirportMapView

@synthesize viewDetailInfo;
@synthesize clManager;

- (void) ShowMsg : (NSString*) strMsg
{
	UIAlertView* pAlertView = [[UIAlertView alloc] initWithTitle:@"提示信息"
														 message:strMsg
														delegate:nil
											   cancelButtonTitle:@"确定"
											   otherButtonTitles:nil];
	[pAlertView show];
	[pAlertView release];
}

-(void) SetDblClkMode:(int) nMode
{
	m_nDblClkMode = nMode;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
	
	
    return self;
}

int OnDbClick(CMapObject* pObj, void* pParam)
{
	NSLog(@"%@", [NSString stringWithUTF8String:pObj->GetObjName().c_str()]);
	if (!pObj->IsShowTip())
	{
		return RE_SUCCESS;
	}
	
	
	
	AirportMapView* pView = (AirportMapView*)pParam;
	
	NSString* strPicPath = [[NSString alloc] initWithUTF8String:pObj->GetPicName().c_str()];
	if (RE_SUCCESS == [pView.viewDetailInfo ShowInfo:strPicPath])
	{
		[pView->DblClkDelegate AfterDoubleClick:DBLCLK_MODE_DETAIL];
	}
	[strPicPath release];
	
	return RE_SUCCESS;
}

- (bool) InitMapInfo:(NSString*) strMapDirName
	  InitDblClkMode:(int) nMode
{
	//获取Documents目录
	NSArray *pathArray = nil;
	pathArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *sDocumentDirectory = nil;
	sDocumentDirectory = [pathArray objectAtIndex:0];
	
	//创建Documents目录
	if (![[NSFileManager defaultManager] fileExistsAtPath:sDocumentDirectory])
	{
		if (![[NSFileManager defaultManager] createDirectoryAtPath:sDocumentDirectory attributes:nil])
		{
			NSLog(@"------------------------create document directory failed----------------");
		}
	}
	
	char szMapDirMap[1024] = {0};
	sprintf(szMapDirMap, "%s/map/%s", [sDocumentDirectory UTF8String],
			[strMapDirName UTF8String]);
	
	if (NULL == m_pMapBusiness)
	{
		CFactoryMapBusiness factoryMapBusiness;
		m_pMapBusiness = factoryMapBusiness.Create(MAP_BUSINESS_2D);
		if (m_pMapBusiness->Init(szMapDirMap, self.frame.size.width, self.frame.size.height) != RE_SUCCESS)
		{
			[self ShowMsg:@"初始化地图数据失败"];
			return false;
		}
		
		m_pMapBusiness->RegisterTouchEvent(TOUCH_MSG_DBCLK, OnDbClick);
	}
	
	if (NULL == m_pMapGraphics)
	{
		CFactoryMapGraphics factoryMapGraphics;
		m_pMapGraphics = factoryMapGraphics.Create(MAP_GRAPHICS_2D);
		if (m_pMapGraphics->Init(szMapDirMap) != RE_SUCCESS)
		{
			[self ShowMsg:@"初始化地图图形失败"];
			return false;
		}
		
		m_pMapGraphics->SetShowPath(true);
	}
	
	m_bMapInfoInit = true;
	m_bZooming = false;
	m_bMoving = false;
	m_nDblClkMode = nMode;
	return true;
}

- (id) initWithCoder : (NSCoder*)coder
{
	if (self = [super initWithCoder:coder])
	{
		[self setMultipleTouchEnabled:true];
		m_bMapInfoInit = false;
		
		//		DetailInfoView* pView = [[DetailInfoView alloc] initWithFrame:CGRectMake(0, 0, 300, 350)];
		//		self.viewDetailInfo = pView;
		//		[pView release];
		//		[self insertSubview:self.viewDetailInfo atIndex:0];
		CLLocationManager* tmpManager = [[CLLocationManager alloc] init];
		self.clManager = tmpManager;
		[tmpManager release];
		
		if ([CLLocationManager headingAvailable])
		{
			clManager.delegate = self;
			[clManager startUpdatingHeading];
		}
	}
	
	return self;
}

- (void)drawRect:(CGRect)rect 
{
    if (m_pMapGraphics != NULL)
	{
		m_pMapGraphics->Render(m_pMapBusiness, self, 0, 0);
	}
}


- (void)dealloc 
{
	SAFE_DELETE(m_pMapBusiness);
	SAFE_DELETE(m_pMapGraphics);
	[viewDetailInfo release];
	[clManager release];
    [super dealloc];
}

- (void) SetDblClkDelegate:(id<AirportMapViewDelegate>) delegate
{
	DblClkDelegate = delegate;
}

- (void) RecalcLayer:(CGPoint) pt
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	int iOffsetX = pt.x - m_ptLast.x;
	int iOffsetY = pt.y - m_ptLast.y;
	
    if (m_pMapBusiness != NULL)
	{
		m_pMapBusiness->Move(-iOffsetX, -iOffsetY);
	}
	[self setNeedsDisplay];
}

- (void) NotifySetBeginPoint:(CGPoint) pt
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_pMapBusiness->ClearPath();
	if (m_pMapBusiness->SetBeginPoint(pt.x, pt.y) != RE_SUCCESS)
	{
		[self ShowMsg:@"您选择的起点位置无法进行定位,请重新选择"];
	}
	else
	{
		[self NotifyCalcPath];
		[DblClkDelegate AfterDoubleClick:DBLCLK_MODE_SET_BEGIN_POINT];
	}
}

- (void) NotifySetEndPoint:(CGPoint) pt
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_pMapBusiness->ClearPath();
	if (m_pMapBusiness->SetEndPoint(pt.x, pt.y) != RE_SUCCESS)
	{
		[self ShowMsg:@"您选择的终点位置无法进行定位,请重新选择"];
	}
	else
	{
		[self NotifyCalcPath];
		[DblClkDelegate AfterDoubleClick:DBLCLK_MODE_SET_END_POINT];
	}
}

- (void) NotifyCalcPath
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	int nRet = m_pMapBusiness->CalcPath();
	if (nRet != RE_SUCCESS)
	{
		if (RE_ERROR_BEGINPT_NOT_SET == nRet)
		{
			//[self ShowMsg:@"您还没有设置起点位置,请将下方的分段按钮选择在\"双击设置起点\"位置后,再通过双击在地图上设置起点"];
		}
		else if (RE_ERROR_ENDPT_NOT_SET == nRet)
		{
			//[self ShowMsg:@"您还没有设置终点位置,请将下方的分段按钮选择在\"双击设置终点\"位置后,再通过双击在地图上设置终点"];
		}
		else
		{
			//[self ShowMsg:@"路径搜索失败,您选择的终点和起点之间没有直达线路"];
		}
	}
	
	[self setNeedsDisplay];
}

- (void) ClearPathInfo
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_pMapBusiness->ClearPath();
	m_pMapBusiness->SetBeginPtValid(false);
	m_pMapBusiness->SetEndPtValid(false);
	[self setNeedsDisplay];
}

- (void) NotifyPressEvent:(CGPoint) pt
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_pMapBusiness->Press(pt.x, pt.y, TOUCH_MSG_DBCLK, (void*)self);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSSet* currTouches = [event touchesForView:self];
	//NSLog(@"Touch Begin");

	if (!m_bMapInfoInit)
	{
		return;
	}
	if ([currTouches count] == 2)
	{
		m_bMoving = false;
		NSArray* twoTouches = [currTouches allObjects];
		UITouch* touchFirst = [twoTouches objectAtIndex:0];
		UITouch* touchSecond = [twoTouches objectAtIndex:1];
		m_fPinchDistance = GetDistanceBetweenPoints([touchFirst locationInView:self], 
													[touchSecond locationInView:self]);
		m_bZooming = true;											
	}
	
	else
	{
		m_bZooming = false;
		UITouch* touch = [touches anyObject];
		m_ptLast = [touch locationInView:self];
		
		NSInteger nTapCount = [touch tapCount];
		
		if (2 == nTapCount)
		{
			m_bMoving = false;
			switch (m_nDblClkMode)
			{
				case DBLCLK_MODE_DETAIL:
				{
					[self NotifyPressEvent:m_ptLast];
					break;
				}
				case DBLCLK_MODE_SET_BEGIN_POINT:
				{
					[self NotifySetBeginPoint:m_ptLast];
					break;
				}
				case DBLCLK_MODE_SET_END_POINT:
				{
					[self NotifySetEndPoint:m_ptLast];
					break;
				}
				default:
				{
					break;
				}
			}
		}
		else
		{
			m_bMoving = true;
		}
		
		[self setNeedsDisplay];
	}
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_fPinchDistance = 0.0f;
	
	if (!m_bZooming && m_bMoving)
	{
		UITouch* touch = [touches anyObject];
		CGPoint ptNew = [touch locationInView:self];
		//NSLog(@"End Calc");
		[self RecalcLayer:ptNew];
		
		m_ptLast = ptNew;
	}
	
	m_bMoving = false;
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSSet* currTouches = [event touchesForView:self];
	if (!m_bMapInfoInit)
	{
		return;
	}
	if ([currTouches count] == 2)
	{
		m_bMoving = false;
		m_bZooming = true;
		NSArray* twoTouches = [currTouches allObjects];
		UITouch* touchFirst = [twoTouches objectAtIndex:0];
		UITouch* touchSecond = [twoTouches objectAtIndex:1];
		CGFloat fCurDistance = GetDistanceBetweenPoints([touchFirst locationInView:self], 
														[touchSecond locationInView:self]);
		
		if (m_fPinchDistance == 0)
		{
			m_fPinchDistance = fCurDistance;
		}
		else if (fCurDistance - m_fPinchDistance > MIN_PINCH_DELTA)
		{
			m_pMapBusiness->Zoom(ZOOM_IN);
			[self setNeedsDisplay];
		}
		else if (m_fPinchDistance - fCurDistance > MIN_PINCH_DELTA)
		{
			m_pMapBusiness->Zoom(ZOOM_OUT);
			[self setNeedsDisplay];
		}
		else
		{
			//do nothing
		}
	}
	else if (m_bMoving)
	{
		m_bZooming = false;
		UITouch* touch = [touches anyObject];
		CGPoint ptNew = [touch locationInView:self];
		//NSLog(@"Moving calc");
		[self RecalcLayer:ptNew];
		
		m_ptLast = ptNew;
	}
	else
	{
		//do nothing
	}
}

- (void) SetPathFromLoc:(int) nFromID
				  ToLoc:(int) nToID
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	m_pMapBusiness->SetPath(nFromID, nToID);
}

- (void) ReleaseGraphicsRes
{
	m_pMapGraphics->Release();
}

- (void) NotifyZoomIn
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	
	m_pMapBusiness->Zoom(ZOOM_IN);
	[self setNeedsDisplay];
}

- (void) NotifyZoomOut
{
	if (!m_bMapInfoInit)
	{
		return;
	}
	
	m_pMapBusiness->Zoom(ZOOM_OUT);
	[self setNeedsDisplay];
}

- (void)locationManager:(CLLocationManager *)manager 
	   didUpdateHeading:(CLHeading *)newHeading
{
	//NSLog(@"trueHeading:%f", newHeading.trueHeading);
	m_pMapBusiness->SetNorthHeading(-newHeading.magneticHeading);
	//[self setNeedsDisplayInRect:CGRectMake(5, 5, 40, 40)];
	[self setNeedsDisplay];
}
@end
