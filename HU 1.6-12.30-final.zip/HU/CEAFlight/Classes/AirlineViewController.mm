//
//  AirlineViewController.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AirlineViewController.h"
#import "CEAFlightAppDelegate.h"

@implementation AirlineViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	[self InitMapInfo:@"map1"
	   InitDblClkMode:DBLCLK_MODE_NULL];
	
	bFlightGateChanged = true;
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload 
{
	[super viewDidUnload];
}


- (void)dealloc 
{
    [super dealloc];
}

- (IBAction) OnDblClkModeChanged:(id) sender
{
	int nIndex = [segmentCtl selectedSegmentIndex];
	[self.viewAirport SetDblClkMode:(nIndex + 1)];
}

- (void) AfterDoubleClick:(int) nMode
{
	if (DBLCLK_MODE_SET_BEGIN_POINT == nMode)
	{
		[segmentCtl setSelectedSegmentIndex:1];
	}
}

- (void)viewDidAppear:(BOOL)animated
{
	UIApplication* app = [UIApplication sharedApplication];
	CEAFlightAppDelegate* appDelegate = (CEAFlightAppDelegate*)[app delegate];
	
	if (appDelegate.flightGate != -1)
	{
		NSLog(@"FlightGate:%d", appDelegate.flightGate);
		[self.viewAirport SetPathFromLoc:0 ToLoc:appDelegate.flightGate];
		bFlightGateChanged = false;
	}
	
	[self.viewAirport setNeedsDisplay];
	[super viewDidAppear:animated];
}

- (void) NotifyFlightGateChanged
{
	bFlightGateChanged = true;
	
}

@end
