//
//  FlightInfoViewController.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-7.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CEAFlightAppDelegate.h"

@interface FlightInfoViewController : UIViewController<UIAlertViewDelegate> {
	CEAFlightAppDelegate * app;
	UIAlertView *alertToGetBarcode;
	UIImageView *hideView;
	
	NSMutableArray *userArray;
	NSMutableArray *flightArray;
	NSMutableArray *toArray;
	NSMutableArray *gateArray;
	NSMutableArray *seatArray;
	
	UILabel *lblName;
	UILabel *lblFlight;
	UILabel *lblTo;
	UILabel *lblGate;
	UILabel *lblSeat;
}

@property(nonatomic,retain) IBOutlet UILabel *lblName;
@property(nonatomic,retain) IBOutlet UILabel *lblFlight;
@property(nonatomic,retain) IBOutlet UILabel *lblTo;
@property(nonatomic,retain) IBOutlet UILabel *lblGate;
@property(nonatomic,retain) IBOutlet UILabel *lblSeat;

@end
