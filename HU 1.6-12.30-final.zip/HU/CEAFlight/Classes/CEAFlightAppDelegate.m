//
//  CEAFlightAppDelegate.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-8.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "CEAFlightAppDelegate.h"



@implementation CEAFlightAppDelegate

@synthesize window;
@synthesize tabBarController;
@synthesize isAlreadyGetBarcode;
@synthesize flightGate;
@synthesize randomNum;

@synthesize barcodeNav;
@synthesize flightInfoNav;
@synthesize gateboardNav;
@synthesize nearByNav;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	
	[NSThread detachNewThreadSelector:@selector(saveLocalImageToPhotoLibrary) 
							 toTarget:self 
						   withObject:nil];
	
	
	if(![self copyMapFileToDocument:@"1base.xml" ToDir:@"map/map1" AsName:@"base.xml"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"1config.xml" ToDir:@"map/map1" AsName:@"config.xml"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"1object.xml" ToDir:@"map/map1" AsName:@"object.xml"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"1pic.png" ToDir:@"map/map1" AsName:@"pic.png"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"1location.xml" ToDir:@"map/map1" AsName:@"location.xml"])
	{
		NSLog(@"Copy map failed! ");
	}
	
	
	if(![self copyMapFileToDocument:@"base.xml" ToDir:@"map/map2"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"config.xml" ToDir:@"map/map2"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"object.xml" ToDir:@"map/map2"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"location.xml" ToDir:@"map/map2"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"pic.png" ToDir:@"map/map2"])
	{
		NSLog(@"Copy map failed! ");
	}
	
	if(![self copyMapFileToDocument:@"Ask.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"BookStore.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"Coffee.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"Depositary.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"Duty.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"KFC.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"McDonald.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"Smoking.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"SuperMarket.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	if(![self copyMapFileToDocument:@"Vip.png" ToDir:@"map/map2/InfoPic"])
	{
		NSLog(@"Copy map failed! ");
	}
	
	flightGate = -1;
	srand(time(NULL));
	randomNum = rand()%6;
	isAlreadyGetBarcode = FALSE;
    [window addSubview:tabBarController.view];
}

-(void)saveLocalImageToPhotoLibrary
{
	UIImage *codeImage = [self getImageFromLocal:@"4.png"];
	if ([self copyMapFileToDocument:@"4.png" ToDir:@"" AsName:@"4.png"])
	{
		UIImageWriteToSavedPhotosAlbum(codeImage,nil,nil,nil);
	}
}

-(UIImage *)getImageFromLocal:(NSString *)imageName
{
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	NSString *defaultFilePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:imageName];
	if (![fileManager fileExistsAtPath:defaultFilePath])
	{
		NSLog(@"file not exist");
		return nil;
	}
	
	NSData *contents = [[NSFileManager defaultManager] contentsAtPath:defaultFilePath];
	return [UIImage imageWithData:contents];
}


-(BOOL)copyMapFileToDocument:(NSString*)fileName ToDir:(NSString*)dirName
{	
    BOOL success = FALSE;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *_error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *dirPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",dirName]];
    if (![fileManager fileExistsAtPath:dirPath]) 
	{
		[fileManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:&_error];
	}
	if ([fileManager fileExistsAtPath:dirPath]) 
	{
		NSString *filePath = [NSString stringWithFormat:@"%@/%@",dirPath,fileName];
		NSString *defaultMapPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:fileName];
		if ([fileManager fileExistsAtPath:defaultMapPath])
		{
			success = [fileManager copyItemAtPath:defaultMapPath toPath:filePath error:&_error];
		}
	}
	return success;
}

-(BOOL)copyMapFileToDocument:(NSString*)fileName ToDir:(NSString*)dirName AsName:(NSString*)destName
{	
    BOOL success = FALSE;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *_error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *dirPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",dirName]];
    if (![fileManager fileExistsAtPath:dirPath]) 
	{
		[fileManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:&_error];
	}
	if ([fileManager fileExistsAtPath:dirPath]) 
	{
		NSString *filePath = [NSString stringWithFormat:@"%@/%@",dirPath,destName];
		NSString *defaultMapPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:fileName];
		if ([fileManager fileExistsAtPath:defaultMapPath])
		{
			success = [fileManager copyItemAtPath:defaultMapPath toPath:filePath error:&_error];
		}
	}
	return success;
}



/*
// Optional UITabBarControllerDelegate method
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
}
*/

/*
// Optional UITabBarControllerDelegate method
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed {
}
*/


- (void)dealloc {
    [tabBarController release];
    [window release];
    [super dealloc];
}

@end

