//
//  AirportMapView.h
//  CEAFlight
//
//  Created by wengyu on 10-12-16.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FactoryMapBusiness.h"
#import "FactoryMapGraphics.h"
#import "DetailInfoView.h"
#import <CoreLocation/CoreLocation.h>

#define TOUCH_MSG_DBCLK 0

#define MIN_PINCH_DELTA 50

#define DBLCLK_MODE_DETAIL 0
#define DBLCLK_MODE_SET_BEGIN_POINT 1
#define DBLCLK_MODE_SET_END_POINT 2
#define DBLCLK_MODE_NULL 3

@protocol AirportMapViewDelegate

- (void) AfterDoubleClick:(int) nMode;

@end

@interface AirportMapView : UIView <CLLocationManagerDelegate>
{
	CMapBusiness* m_pMapBusiness;
	CMapGraphics* m_pMapGraphics;
	CGPoint m_ptLast;
	CGFloat m_fPinchDistance;
	bool m_bZooming;
	bool m_bMoving;
	int m_nDblClkMode;
	bool m_bMapInfoInit;
	id<AirportMapViewDelegate> DblClkDelegate;
	DetailInfoView* viewDetailInfo;
	CLLocationManager* clManager;
}

- (void) SetDblClkMode:(int) nMode; 
- (void) ClearPathInfo;
- (void) NotifyCalcPath;
- (bool) InitMapInfo:(NSString*) strMapDirName
	  InitDblClkMode:(int) nMode;
- (void) SetDblClkDelegate:(id<AirportMapViewDelegate>) delegate;

- (void) SetPathFromLoc:(int) nID
				  ToLoc:(int) nID;

- (void) ReleaseGraphicsRes;
- (void) NotifyZoomIn;
- (void) NotifyZoomOut;

@property (nonatomic, retain) IBOutlet DetailInfoView* viewDetailInfo;
@property (nonatomic, retain) CLLocationManager* clManager;

@end
