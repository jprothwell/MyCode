
#import <UIKit/UIKit.h>


@interface ScannedImageView : UIView {
  UIImage *image;
  NSMutableArray *resultPoints;
}

@property (nonatomic, retain) UIImage *image;

- (void) addResultPoint:(CGPoint)p;

@end
