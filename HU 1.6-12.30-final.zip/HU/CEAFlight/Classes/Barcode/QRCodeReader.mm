
#import "QRCodeReader.h"
#import <zxing/qrcode/QRCodeReader.h>
#import "FormatReader.h"

@implementation QRCodeReader


- (id) init {
  zxing::qrcode::QRCodeReader *reader = new zxing::qrcode::QRCodeReader();
  return [super initWithReader:reader];
}
@end
