

#import <UIKit/UIKit.h>

@protocol CancelDelegate;

@interface OverlayView : UIView {
	UIImageView *imageView;
	NSMutableArray *_points;
	UIButton *cancelButton;
	id<CancelDelegate> delegate;
	BOOL oneDMode;
        CGRect cropRect;
	
	//add by songshanping @2010.12.23
	UIImageView *bgImgView;
	UIToolbar *bottomBar;
	UIBarButtonItem *cancelBarItem;
	
	UIImageView *lineImage;
	NSTimer *lineTimer;
	int lineCount;
}

@property (nonatomic, retain) NSMutableArray*  points;
@property (nonatomic, assign) id<CancelDelegate> delegate;
@property (nonatomic, assign) BOOL oneDMode;
@property (nonatomic, assign) CGRect cropRect;

- (id)initWithFrame:(CGRect)theFrame cancelEnabled:(BOOL)isCancelEnabled oneDMode:(BOOL)isOneDModeEnabled;

- (void)setPoint:(CGPoint)point;

-(void)startTimer;
- (void)timerMethod;
-(void)stopTimer;

@end

@protocol CancelDelegate
- (void)cancelled;
@end
