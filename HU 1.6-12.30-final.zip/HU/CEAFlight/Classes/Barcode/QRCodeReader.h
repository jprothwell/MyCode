
#import <Foundation/Foundation.h>
#import "FormatReader.h"

@interface QRCodeReader : FormatReader {

}
- (id) init;
@end
