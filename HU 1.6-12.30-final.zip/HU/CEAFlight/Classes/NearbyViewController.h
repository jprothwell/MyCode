//
//  NearbyViewController.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirportMapViewController.h"

@interface NearbyViewController : AirportMapViewController
{
	UIBarButtonItem* btnLeft;
	UIBarButtonItem* btnRight;
	UIBarButtonItem* btnReturn;
}

@property (nonatomic, retain) UIBarButtonItem* btnLeft;
@property (nonatomic, retain) UIBarButtonItem* btnRight;
@property (nonatomic, retain) UIBarButtonItem* btnReturn;

- (IBAction) OnBtnReturn:(id) sender;
@end
