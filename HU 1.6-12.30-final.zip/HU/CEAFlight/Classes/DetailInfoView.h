//
//  DetailInfoView.h
//  CEAFlight
//
//  Created by wengyu on 10-12-20.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DetailInfoView : UIView 
{
	UIImageView* imgView;
}

@property (nonatomic, retain) IBOutlet UIImageView* imgView;

- (int) ShowInfo:(NSString*) strPicPath;

- (void) HideInfo;

@end
