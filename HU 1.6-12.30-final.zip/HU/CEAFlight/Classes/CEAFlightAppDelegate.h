//
//  CEAFlightAppDelegate.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-8.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CEAFlightAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate> {
    UIWindow *window;
    UITabBarController *tabBarController;
	BOOL isAlreadyGetBarcode;
	int flightGate;
	
	UINavigationController *barcodeNav;
	UINavigationController *flightInfoNav;
	UINavigationController *gateboardNav;
	UINavigationController *nearByNav;
	int randomNum;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;

@property (nonatomic, retain) IBOutlet UINavigationController *barcodeNav;
@property (nonatomic, retain) IBOutlet UINavigationController *flightInfoNav;
@property (nonatomic, retain) IBOutlet UINavigationController *gateboardNav;
@property (nonatomic, retain) IBOutlet UINavigationController *nearByNav;

@property (nonatomic) BOOL isAlreadyGetBarcode;
@property (nonatomic) int flightGate;
@property (nonatomic) int randomNum;

-(UIImage *)getImageFromLocal:(NSString *)imageName;

-(BOOL)copyMapFileToDocument:(NSString*)fileName ToDir:(NSString*)dirName;
-(BOOL)copyMapFileToDocument:(NSString*)fileName ToDir:(NSString*)dirName AsName:(NSString*)destName;

@end
