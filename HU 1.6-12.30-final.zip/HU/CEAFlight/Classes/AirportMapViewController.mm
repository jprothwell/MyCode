//
//  AirportMapViewController.m
//  CEAFlight
//
//  Created by wengyu on 10-12-20.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AirportMapViewController.h"


@implementation AirportMapViewController

@synthesize viewAirport;
@synthesize segmentCtl;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView {
 }
 */
- (void) InitMapInfo:(NSString*) strMapName
	  InitDblClkMode:(int) nMode
{
	[self.viewAirport InitMapInfo:strMapName
	 InitDblClkMode:nMode];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
	UIBarButtonItem* btnBar = [[UIBarButtonItem alloc] initWithTitle:@"放大"
															   style:UIBarButtonItemStyleBordered
															  target:self
															  action:@selector(OnBtnZoomIn:)];
	self.navigationItem.leftBarButtonItem = btnBar;
	[btnBar release];
	
	btnBar = [[UIBarButtonItem alloc] initWithTitle:@"缩小"
											  style:UIBarButtonItemStyleBordered
											 target:self
											 action:@selector(OnBtnZoomOut:)];
	self.navigationItem.rightBarButtonItem = btnBar;
	[btnBar release];
	
	[self.viewAirport SetDblClkDelegate:self];
    [super viewDidLoad];
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	self.viewAirport = nil;
	self.segmentCtl = nil;
	[super viewDidUnload];
}


- (void)dealloc
{
   	[viewAirport release];
	[segmentCtl release];
    [super dealloc];
}

- (IBAction) OnDblClkModeChanged:(id) sender
{
	
}

- (IBAction) OnBtnZoomOut:(id) sender
{
	[viewAirport NotifyZoomOut];
}
- (IBAction) OnBtnZoomIn:(id) sender
{
	[viewAirport NotifyZoomIn];
}

- (void) AfterDoubleClick:(int) nMode
{
	
}

- (void)viewDidDisappear:(BOOL)animated
{
	[viewAirport ReleaseGraphicsRes];
	[super viewDidDisappear:animated];
}

@end
