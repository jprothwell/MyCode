//
//  FlightInfoViewController.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-7.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FlightInfoViewController.h"


@implementation FlightInfoViewController

@synthesize lblTo;
@synthesize lblGate;
@synthesize lblName;
@synthesize lblFlight;
@synthesize lblSeat;

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (alertView == alertToGetBarcode)
	{
		[hideView removeFromSuperview];
		self.tabBarController.selectedIndex = 0;
	}
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

- (void)initArrays
{
	userArray = [[NSMutableArray alloc] initWithObjects:@"John Smith",@"Mike Jordan",@"Goran Smith",@"Larry Bird",@"Kavin Durant",@"Sam Josh",nil];
	toArray = [[NSMutableArray alloc] initWithObjects:@"Beijing",@"Nanjing",@"Shanghai",@"Guangzhou",@"Haikou",@"Nanning",nil];
	flightArray = [[NSMutableArray alloc] initWithObjects:@"FM 9365",@"FA 93475",@"FM 9325",@"BM 8665",@"QM 9865",@"Fd 9385",nil];
	gateArray = [[NSMutableArray alloc] initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",nil];
	seatArray = [[NSMutableArray alloc] initWithObjects:@"15D",@"23F",@"31F",@"24C",@"25C",@"26D",nil];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	app = (CEAFlightAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	hideView = [[UIImageView alloc] initWithFrame:CGRectMake(0, -43, 320, 460)];
	hideView.backgroundColor = [UIColor clearColor];
	hideView.image = [UIImage imageNamed:@"bg.png"];
	
	
	[self initArrays];
}

- (void)viewWillAppear:(BOOL)animated
{
	[hideView removeFromSuperview];
	if (!app.isAlreadyGetBarcode)
	{
		[self.view addSubview:hideView];
		
		alertToGetBarcode = [[UIAlertView alloc] initWithTitle:@"" message:@"Please get the barcode first!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alertToGetBarcode show];
		[alertToGetBarcode release];
	}
	else
	{
		int randomNum = app.randomNum;
		lblName.text = [userArray objectAtIndex:randomNum];
		lblFlight.text = [flightArray objectAtIndex:randomNum];
		lblTo.text = [toArray objectAtIndex:randomNum];
		lblGate.text = [gateArray objectAtIndex:randomNum];
		lblSeat.text = [seatArray objectAtIndex:randomNum];
		NSString *gateStr = [gateArray objectAtIndex:randomNum];
		app.flightGate = [gateStr intValue];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[hideView release];
	
	[userArray release];
	[flightArray release];
	[toArray release];
	[gateArray release];
	[seatArray release];
}


@end
