//
//  AirportMapViewController.h
//  CEAFlight
//
//  Created by wengyu on 10-12-20.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirportMapView.h"


@interface AirportMapViewController : UIViewController<AirportMapViewDelegate>
{
	AirportMapView* viewAirport;
	UISegmentedControl* segmentCtl;
}

@property (nonatomic, retain) IBOutlet AirportMapView* viewAirport;
@property (nonatomic, retain) IBOutlet UISegmentedControl* segmentCtl;

- (IBAction) OnDblClkModeChanged:(id) sender;
- (IBAction) OnBtnZoomIn:(id) sender;
- (IBAction) OnBtnZoomOut:(id) sender;

- (void) InitMapInfo:(NSString*) strMapName
	  InitDblClkMode:(int) nMode;
@end
