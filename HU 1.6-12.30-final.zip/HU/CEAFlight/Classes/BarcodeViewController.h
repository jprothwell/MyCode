//
//  BarcodeViewController.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CEAFlightAppDelegate.h"

#import "ScannedImageView.h"
#import "ZXingWidgetController.h"

#include <AudioToolbox/AudioToolbox.h>
#import "Barcode/Decoder.h"
#import "ScannedImageView.h"
#import "ParsedResult.h"
#import "ResultAction.h"
#import "ResultParser.h"
#import "TwoDDecoderResult.h"

@interface BarcodeViewController : UIViewController 
<ZXingDelegate, DecoderDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate,UINavigationControllerDelegate> {
	
	IBOutlet UITextView *messageText;
	IBOutlet UIButton *cameraBtn;
	IBOutlet UIButton *libraryBtn;
	
	IBOutlet ScannedImageView *imageView;
	
	Decoder *decoder;
	ParsedResult *result;
	NSArray *actions;
	
	NSMutableArray *resultPointViews;
	UIImage *noImage;
	
	CEAFlightAppDelegate *app;
	
	UIImage *resultImage;
	
	UILabel *lblLoading;
	
	BOOL isFirstDecode;
	BOOL isPhotoLibraryUp;
	
	UIImagePickerController *imagePickerController;
	
	
	CFURLRef		soundFileURLRef;
	SystemSoundID	soundFileObject;
}

@property (nonatomic, retain) UIImage *resultImage;
@property (nonatomic, retain) IBOutlet UIButton *cameraBtn;
@property (nonatomic, retain) IBOutlet UIButton *libraryBtn;
@property (nonatomic, retain) IBOutlet UITextView *messageText;
@property (nonatomic, retain) IBOutlet UILabel *lblLoading;
@property (nonatomic, retain) IBOutlet ScannedImageView *imageView;

@property (nonatomic, retain) NSMutableArray *resultPointViews;
@property (nonatomic, retain) UIImage *noImage;

- (void)pickAndDecodeFromSource:(UIImagePickerControllerSourceType) sourceType;
- (IBAction)pickAndDecode:(id)sender;

- (void)gotoDetailView;
- (void)clearImageView;
- (void)showCaptureView;

@end
