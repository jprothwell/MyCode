//
//  AirlineViewController.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AirportMapViewController.h"

@interface AirlineViewController : AirportMapViewController
{
	bool bFlightGateChanged;
}

- (void) NotifyFlightGateChanged;

@end
