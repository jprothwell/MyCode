//
//  FlightInfo.h
//  CEAFlight
//
//  Created by SongShanping on 10-12-19.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FlightInfo : NSObject {

}

@end
