//
//  FlightInfo.m
//  CEAFlight
//
//  Created by SongShanping on 10-12-19.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FlightInfo.h"


@implementation FlightInfo

@end
