//
//  DetailInfoView.m
//  CEAFlight
//
//  Created by wengyu on 10-12-20.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DetailInfoView.h"
#include "common.h"

@implementation DetailInfoView

@synthesize imgView;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}

- (id) initWithCoder : (NSCoder*)coder
{
	if (self = [super initWithCoder:coder])
	{
	    UIImageView* tmpImgView = [[UIImageView alloc] init];
		tmpImgView.frame = self.frame;
		//		tmpImgView.frame.origin.x += 5;
		//		tmpImgView.frame.origin.y += 5;
		//		tmpImgView.frame.size.width -= 10;
		//		tmpImgView.frame.size.height -= 10;
		self.imgView = tmpImgView;
		[self insertSubview:self.imgView atIndex:100];
		[tmpImgView release];
	}
	
	return self;
}

- (void)drawRect:(CGRect)rect 
{
    // Drawing code
}


- (void)dealloc {
	[imgView release];
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//[self HideInfo];
}

- (int) ShowInfo:(NSString*) strPicPath
{
	UIImage* img = [[UIImage alloc] initWithContentsOfFile:strPicPath];
	if (img != nil)
	{
		[imgView setImage:img];
		[img release];
		
		[UIView beginAnimations:@"Show Detail" context:nil];
		[UIView setAnimationDuration:0.75];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
		[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self cache:YES];
		[self setHidden:false];
		[UIView commitAnimations];
		
		return RE_SUCCESS;
	}
	else
	{
		return RE_FAILED;
	}
}

- (void) HideInfo
{
	[UIView beginAnimations:@"Hide Detail" context:nil];
	[UIView setAnimationDuration:0.75];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self cache:YES];
	[self setHidden:true];
	[UIView commitAnimations];
}
@end
