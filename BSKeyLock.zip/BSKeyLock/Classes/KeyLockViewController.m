//
//  KeyLockViewController.m
//
//  Created by Björn Sållarp on 6/5/10.
//  NO Copyright 2009 MightyLittle Industries. NO rights reserved.
// 
//  Use this code any way you like. If you do like it, please
//  link to my blog and/or write a friendly comment. Thank you!
//
//  Read my blog @ http://blog.sallarp.com
//
#import "KeyLockViewController.h"


@implementation KeyLockViewController
@synthesize titleText, appDelegate;


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	// Adjust the frame a little, otherwise it's partly behind the status-bar
	self.view.frame = CGRectMake(0, 20, 320, 460);
	
	BSKeyLock *lock = [[BSKeyLock alloc] initWithFrame:CGRectMake(0, 70, 320, 295)];
	lock.delegate = appDelegate;
	[lock setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"keylockbg.png"]]];
	[self.view addSubview:lock];
	[lock release];
	
	titleLabel.text = titleText;
}

-(void)setTitleText:(NSString*)value
{
	if (titleText != value)
    {
        [titleText release];
        titleText = [value copy];
		titleLabel.text = value;
    }
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[titleText release];
    [super dealloc];
}


@end
