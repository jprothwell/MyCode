//
//  LoggedInViewController.m
//
//  Created by Björn Sållarp on 6/5/10.
//  NO Copyright 2009 MightyLittle Industries. NO rights reserved.
// 
//  Use this code any way you like. If you do like it, please
//  link to my blog and/or write a friendly comment. Thank you!
//
//  Read my blog @ http://blog.sallarp.com
//
#import "LoggedInViewController.h"


@implementation LoggedInViewController


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	
	lockSwitch.on = [settings objectForKey:@"KeyLockCombo"] != nil;
}



-(void)validateKeyCombination:(NSArray*)keyCombination sender:(id)sender
{
	// We require at least four points to be connected in the combination
	if([keyCombination count] > 3)
	{
		// Store the combo and remove the keypad.
		NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
		[settings setObject:keyCombination forKey:@"KeyLockCombo"];
		[settings synchronize];
		
		[keyLock.view removeFromSuperview];
		
		lockSwitch.on = YES;
	}
	else 
	{
		[(BSKeyLock*)sender deemKeyCombinationInvalid];		
	}
}

-(IBAction)lockSwitchChanged:(id)sender
{
	// Show the key lock pad if it's on.
	if([(UISwitch*)sender isOn])
	{
		if(keyLock == nil)
		{
			keyLock = [[KeyLockViewController alloc] initWithNibName:@"KeyLockView" bundle:[NSBundle mainBundle]];
			keyLock.appDelegate = self;
		}
		
		keyLock.titleText = @"Draw pattern. 3 points minimum!";
		
		[self.view addSubview:keyLock.view];
		
		// Set the switch back to NO, we want the user to set a key for it to be active
		[lockSwitch setOn:NO];
	}
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[keyLock release];
    [super dealloc];
}


@end
