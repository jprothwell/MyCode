//
//  BSKeyLockAppDelegate.m
//
//  Created by Björn Sållarp on 6/5/10.
//  NO Copyright 2009 MightyLittle Industries. NO rights reserved.
// 
//  Use this code any way you like. If you do like it, please
//  link to my blog and/or write a friendly comment. Thank you!
//
//  Read my blog @ http://blog.sallarp.com
//
#import "BSKeyLockAppDelegate.h"


@implementation BSKeyLockAppDelegate

@synthesize window;
@synthesize navigationController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
	loggedInController = [[LoggedInViewController alloc] initWithNibName:@"LoggedInView" bundle:[NSBundle mainBundle]];
    keyLockController = [[KeyLockViewController alloc] initWithNibName:@"KeyLockView" bundle:[NSBundle mainBundle]];
    keyLockController.appDelegate = self;
	
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	
	// Start the application by showing the key combination if one is defined.
	if([settings objectForKey:@"KeyLockCombo"] != nil)
	{
		keyLockController.titleText = @"Draw pattern to unlock";
		[window addSubview:keyLockController.view];
	}
	// If no combination has been set, we let the user into out magic app.
	else 
	{
		[window addSubview:loggedInController.view];
	}

    [window makeKeyAndVisible];

    return YES;
}


#pragma mark -
#pragma mark BSKeyLockDelegate methods

-(void)validateKeyCombination:(NSArray*)keyCombination sender:(id)sender
{
	
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	NSArray *storedKeyCombo = [settings objectForKey:@"KeyLockCombo"];
	int storedKeyComboCount = [storedKeyCombo count];
	
	BOOL comboIsValid = storedKeyComboCount == [keyCombination count];
	
	if (comboIsValid)
	{
		for (int i = 0; i < storedKeyComboCount; i++) {
			if([storedKeyCombo objectAtIndex:i] != [keyCombination objectAtIndex:i])
			{
				comboIsValid = NO;
				break;
			}
		}
	}
	
	if(comboIsValid)
	{
		// The combination is valid, let the user into the app.
		[[keyLockController view] removeFromSuperview];
		[window addSubview:loggedInController.view];
		
		// Reset the attempts to log in
		[settings setObject:[NSNumber numberWithInt:0] forKey:@"KeyLockFailedTries"];
		
		[keyLockController release];
	}
	else {
		
		int attempt = 0;
		if([settings objectForKey:@"KeyLockFailedTries"] != nil) {
			attempt = [[settings objectForKey:@"KeyLockFailedTries"] intValue];
		}
		
		// Increase the failed attempts to log in		 
		attempt++;
		[settings setObject:[NSNumber numberWithInt:attempt] forKey:@"KeyLockFailedTries"];
		
		if(attempt < 3)
		{
			[(BSKeyLock*)sender deemKeyCombinationInvalid];
			keyLockController.titleText = [NSString stringWithFormat:@"Sorry, try again! Attempts left: %d", 3 - attempt];
		}
		else 
		{
			// The user failed three times. Remove all settings and let them into the app
			[settings setObject:[NSNumber numberWithInt:0] forKey:@"KeyLockFailedTries"];
			[settings setObject:nil forKey:@"KeyLockCombo"];
		
		
			// Show an alert informing the user that he/she screwd up!
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too many failed attempts!" 
															message:@"Due to too many failed login attempts the application has been wiped of information." 
														   delegate:nil 
												  cancelButtonTitle:@"OK" 
												  otherButtonTitles:nil];
			[alert show];
			[alert release];
			
			[[keyLockController view] removeFromSuperview];
			[window addSubview:loggedInController.view];
			
			[keyLockController release];
		}
	}
	
	// Persist changes
	[settings synchronize];
	
}

#pragma mark -


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
	[loggedInController release];
	[navigationController release];
	[window release];
	[super dealloc];
}


@end

