//
//  KeyLockViewController.h
//
//  Created by Björn Sållarp on 6/5/10.
//  NO Copyright 2009 MightyLittle Industries. NO rights reserved.
// 
//  Use this code any way you like. If you do like it, please
//  link to my blog and/or write a friendly comment. Thank you!
//
//  Read my blog @ http://blog.sallarp.com
//
#import <UIKit/UIKit.h>
#import "BSKeyLock.h"

@interface KeyLockViewController : UIViewController {
	IBOutlet UILabel *titleLabel;
	id<BSKeyLockDelegate, NSObject> appDelegate;
	NSString *titleText;
}
@property (nonatomic, retain) NSString *titleText;
@property (nonatomic, assign) id<BSKeyLockDelegate, NSObject> appDelegate;

@end
