//
//  DrawPatternLockView.m
//  AndroidLock
//
//  Created by Purnama Santo on 11/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "DrawPatternLockView.h"

#define MATRIX_SIZE 3


@interface DrawPatternLockView()

@property (nonatomic, retain) NSValue *_trackPointValue;
@property (nonatomic, retain) NSMutableArray *_dotViews;
@property (nonatomic, retain) NSMutableArray* _paths;

- (void)clearDotViews;
- (void)addDotView:(UIView*)view;
- (void)drawLineFromLastDotTo:(CGPoint)pt;
- (void)touchPoint:(CGPoint)aPoint view:(UIView*)aView;

@end


@implementation DrawPatternLockView

@synthesize _trackPointValue;
@synthesize _dotViews;
@synthesize _paths;

- (void) dealloc
{
	[_trackPointValue release];
	[_dotViews release];
	[_paths release];
	[super dealloc];
}

- (void) setup
{
	self.backgroundColor = [UIColor whiteColor];
	
	int intNum = 0;
	for (int i=0; i<MATRIX_SIZE; i++) {
		for (int j=0; j<MATRIX_SIZE; j++) {
			UIImage *dotImage = [UIImage imageNamed:@"dot_off.png"];
			UIImageView *imageView = [[UIImageView alloc] initWithImage:dotImage
													   highlightedImage:[UIImage imageNamed:@"dot_on.png"]];
			imageView.frame = CGRectMake(0, 0, dotImage.size.width, dotImage.size.height);
			imageView.userInteractionEnabled = YES;
			imageView.tag = j*MATRIX_SIZE + i + 1;
			
			int w = self.frame.size.width/MATRIX_SIZE;
			int h = self.frame.size.height/MATRIX_SIZE;
			int x = w*(intNum/MATRIX_SIZE) + w/2;
			int y = h*(intNum%MATRIX_SIZE) + h/2;
			
			imageView.center = CGPointMake(x, y);
			intNum++;

			
			[self addSubview:imageView];
		}
	}
	
	_dotViews = [[NSMutableArray alloc]init];
	_paths = [[NSMutableArray alloc] init];
	
}

- (id)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if (self) {
    // Initialization code
	  [self setup];
  }

  return self;
}

- (void)touchPoint:(CGPoint)aPoint view:(UIView*)aView
{
	//	
	[self drawLineFromLastDotTo:aPoint];
	
	if (aView!=self) {
		NSLog(@"touched view tag: %d ", aView.tag);
		
		BOOL found = NO;
		for (NSNumber *tag in _paths) {
			
			if ([tag intValue] == aView.tag ) {
				found = YES;
			}
			
			if (found)
				break;
		}
		
		if (found)
			return;
		
		
		UIImageView* iv = (UIImageView*)aView;
		iv.highlighted = YES;
		
		[_paths addObject:[NSNumber numberWithInt:iv.tag]];
		[self addDotView:iv];
	}
}

#pragma mark -
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	// clear up hilite
	[self clearDotViews];
	[_paths removeAllObjects];
	
	CGPoint pt = [[touches anyObject] locationInView:self];
	UIView *touched = [self hitTest:pt withEvent:event];
	[self touchPoint:pt view:touched];
}



- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	
	CGPoint pt = [[touches anyObject] locationInView:self];
	UIView *touched = [self hitTest:pt withEvent:event];
	[self touchPoint:pt view:touched];
}


- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	
	[self clearDotViews];

	for (UIView *view in self.subviews)
		if ([view isKindOfClass:[UIImageView class]])
			[(UIImageView*)view setHighlighted:NO];
	
	[self setNeedsDisplay];
	
	// pass the output to target action...
//	if (_target && _action)
//		[_target performSelector:_action withObject:[self getKey]];
}
#pragma mark -

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
  NSLog(@"drawrect...");
  
  if (!_trackPointValue)
    return;

  CGContextRef context = UIGraphicsGetCurrentContext();
  CGContextSetLineWidth(context, 20.0);
  CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
  CGFloat components[] = {0.5, 0.5, 0.5, 0.8};
  CGColorRef color = CGColorCreate(colorspace, components);
  CGContextSetStrokeColorWithColor(context, color);

  CGPoint from;
  UIView *lastDot = nil;
  for (UIView *dotView in _dotViews) {
    from = dotView.center;
    NSLog(@"drwaing dotview: %d", dotView.tag);
//    NSLog(@"\tdrawing from: %f, %f", from.x, from.y);

    if (!lastDot)
      CGContextMoveToPoint(context, from.x, from.y);
    else
      CGContextAddLineToPoint(context, from.x, from.y);
    
    lastDot = dotView;
  }

  CGPoint pt = [_trackPointValue CGPointValue];
//  NSLog(@"\t to: %f, %f", pt.x, pt.y);
  CGContextAddLineToPoint(context, pt.x, pt.y);
  
  CGContextStrokePath(context);
  CGColorSpaceRelease(colorspace);
  CGColorRelease(color);

}


- (void)clearDotViews {
  [_dotViews removeAllObjects];
}


- (void)addDotView:(UIView *)view {

	if (view) {
		[_dotViews addObject:view];
	}
  
}


- (void)drawLineFromLastDotTo:(CGPoint)pt {
	self._trackPointValue = [NSValue valueWithCGPoint:pt];
	[self setNeedsDisplay];
}


@end
