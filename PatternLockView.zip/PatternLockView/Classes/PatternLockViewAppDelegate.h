//
//  PatternLockViewAppDelegate.h
//  PatternLockView
//
//  Created by jinglei on 12-3-24.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PatternLockViewViewController;

@interface PatternLockViewAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    PatternLockViewViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet PatternLockViewViewController *viewController;

@end

