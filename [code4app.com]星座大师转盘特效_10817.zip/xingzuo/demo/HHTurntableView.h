//
//  HHTurntableView.h
//  demo
//
//  Created by Eric on 12-3-9.
//  Copyright (c) 2012年 Tian Tian Tai Mei Net Tech (Bei Jing) Lt.d. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HHTurntableView : UIView
{
    NSInteger currentTag;
    BOOL animationIng;
}
@end
