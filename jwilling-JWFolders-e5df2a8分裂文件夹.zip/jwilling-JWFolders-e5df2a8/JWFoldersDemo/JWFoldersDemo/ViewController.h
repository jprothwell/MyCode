#import <UIKit/UIKit.h>
#import "FolderViewController.h"

@interface ViewController : UIViewController
{
    FolderViewController *sampleFolder;
}

- (IBAction)openFolder:(id)sender;

@end
