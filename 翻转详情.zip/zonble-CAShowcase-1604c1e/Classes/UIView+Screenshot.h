#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UIView (Screenshot)

- (UIImage *)screenshot;

@end
