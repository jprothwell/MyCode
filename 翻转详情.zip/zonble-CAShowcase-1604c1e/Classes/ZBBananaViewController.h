#import "ZBBananaLayer.h"

@interface ZBBananaViewController : UIViewController
{
	ZBBananaLayer *bananaLayer;
}

- (void)move;

@end

