#import <QuartzCore/QuartzCore.h>

@interface ZBAnimateTableViewController : UITableViewController 
{
	CALayer *transitionLayer;
}

@end
