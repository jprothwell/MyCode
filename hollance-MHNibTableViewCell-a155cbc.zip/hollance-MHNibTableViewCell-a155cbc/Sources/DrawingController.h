
/*
 * Demo for the DrawingCell table view cells.
 *
 * This uses a nib to load the view, so we can use a GradientBackgroundTable
 * instead of a regular UITableView.
 */
@interface DrawingController : UITableViewController
{
}

@end
